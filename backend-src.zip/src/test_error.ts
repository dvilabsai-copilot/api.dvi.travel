﻿const x: number = 'string';
