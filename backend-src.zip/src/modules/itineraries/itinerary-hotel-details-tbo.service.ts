// FILE: src/modules/itineraries/itinerary-hotel-details-tbo.service.ts

import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { HotelSearchService } from '../hotels/services/hotel-search.service';
import { HobseHotelProvider } from '../hotels/providers/hobse-hotel.provider';
import { HotelSearchResult } from '../hotels/interfaces/hotel-provider.interface';
import {
  ItineraryHotelTabDto,
  ItineraryHotelRowDto,
  ItineraryHotelDetailsResponseDto,
  ItineraryHotelRoomDetailsResponseDto,
  ItineraryHotelRoomDto,
} from './itinerary-hotel-details.service';
import { haversineKm } from './utils/distance-utils';

/**
 * This service generates dynamic hotel packages from TBO API
 * instead of retrieving them from the database
 */
@Injectable()
export class ItineraryHotelDetailsTboService {
  private static readonly HOTEL_DETAILS_CACHE_TTL_MS = 5 * 60 * 1000;
  private static readonly HOTEL_ROOM_DETAILS_CACHE_TTL_MS = 5 * 60 * 1000;
  private static readonly MAX_CACHE_ENTRIES = 200;

    /**
     * Fetch hotels for all routes, retrying ONCE if any provider/system failure (null) is detected.
     */
    private async fetchHotelsForRoutesWithRetry(
      routes: any[],
      noOfNights: number,
      guestNationality: string,
      roomCount: number = 1,
      adultCount: number = 2,
      childCount: number = 0,
      childAges: number[] = [],
    ): Promise<Map<number, HotelSearchResult[] | null>> {
      let hotelsByRoute = await this.fetchHotelsForRoutes(
        routes,
        noOfNights,
        guestNationality,
        roomCount,
        adultCount,
        childCount,
        childAges,
      );

      const hasProviderFailure = Array.from(hotelsByRoute.values()).some(
        (value) => value === null,
      );

      if (hasProviderFailure) {
        this.logger.warn(
          '🚨 Hotel search had provider/system failure on first attempt. Retrying once...'
        );

        // small delay to allow DB sync / provider readiness
        await new Promise((resolve) => setTimeout(resolve, 800));

        const retryResult = await this.fetchHotelsForRoutes(
          routes,
          noOfNights,
          guestNationality,
          roomCount,
          adultCount,
          childCount,
          childAges,
        );

        const retryStillFailed = Array.from(retryResult.values()).some(
          (value) => value === null,
        );

        // compare number of successful routes (non-empty arrays)
        const retrySuccessCount = Array.from(retryResult.values()).filter(
          (v) => Array.isArray(v) && v.length > 0,
        ).length;

        const firstSuccessCount = Array.from(hotelsByRoute.values()).filter(
          (v) => Array.isArray(v) && v.length > 0,
        ).length;

        this.logger.log(
          `📊 Comparing results → First: ${firstSuccessCount}, Retry: ${retrySuccessCount}`,
        );

        // return whichever has more valid hotel data
        if (retrySuccessCount >= firstSuccessCount) {
          this.logger.log('✅ Using retry result (better or equal)');
          return retryResult;
        } else {
          this.logger.log('⚠️ Using first attempt result (better)');
          return hotelsByRoute;
        }
      }

      return hotelsByRoute;
    }
  private readonly logger = new Logger(ItineraryHotelDetailsTboService.name);

  private static readonly ONE_DAY_MS = 24 * 60 * 60 * 1000;

  // Cache for hotel details endpoint response (key = quoteId)
  private hotelDetailsCache = new Map<string, {
    data: ItineraryHotelDetailsResponseDto;
    timestamp: number;
  }>();
  
  // Cache structure: key = "quoteId:routeId" or "quoteId" (no route filter)
  // Stores the entire response to avoid re-fetching TBO data
  private hotelRoomDetailsCache = new Map<string, {
    data: ItineraryHotelRoomDetailsResponseDto;
    timestamp: number;
  }>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly hotelSearchService: HotelSearchService,
    private readonly hobseProvider: HobseHotelProvider,
  ) {}

  private extractIso2FromCountryRow(row: any): string | null {
    if (!row || typeof row !== 'object') return null;

    const candidates = [
      row.shortname,
      row.country_code,
      row.iso2,
      row.iso_code,
      row.sortname,
      row.alpha2,
      row.code,
    ];

    for (const value of candidates) {
      const normalized = String(value ?? '').trim().toUpperCase();
      if (/^[A-Z]{2}$/.test(normalized)) {
        return normalized;
      }
    }

    return null;
  }

  private async resolveGuestNationality(plan: any): Promise<string> {
    const nationalityId = Number((plan as any)?.nationality ?? 0);
    const rawNationality = String((plan as any)?.nationality ?? '')
      .trim()
      .toUpperCase();

    // Prefer master-country mapping from DB (as requested).
    if (nationalityId > 0) {
      try {
        const country = await this.prisma.dvi_countries.findFirst({
          where: {
            id: nationalityId,
            deleted: 0,
            status: 1,
          },
          select: {
            shortname: true,
            name: true,
          },
        });
        const iso2 = this.extractIso2FromCountryRow(country);
        if (iso2) {
          this.logger.log(
            `✅ Resolved guestNationality from country table: nationality=${nationalityId} -> ${iso2}`,
          );
          return iso2;
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        this.logger.warn(
          `⚠️ Could not resolve country mapping from table dvi_countries for nationality=${nationalityId}: ${message}`,
        );
      }
    }

    // Some records may directly store ISO-2 code instead of FK id.
    if (/^[A-Z]{2}$/.test(rawNationality)) {
      this.logger.warn(
        `⚠️ Using direct ISO-2 nationality from plan value: ${rawNationality}`,
      );
      return rawNationality;
    }

    const envFallback = String(
      process.env.TBO_DEFAULT_GUEST_NATIONALITY || '',
    )
      .trim()
      .toUpperCase();
    if (/^[A-Z]{2}$/.test(envFallback)) {
      this.logger.warn(
        `⚠️ Using TBO_DEFAULT_GUEST_NATIONALITY fallback: ${envFallback}`,
      );
      return envFallback;
    }

    this.logger.warn(
      '⚠️ Unable to resolve guestNationality from plan/country table/env. Falling back to IN.',
    );
    return 'IN';
  }

  /**
   * Get hotel details with dynamic packages from TBO API
   * Creates 4 different price tier packages: Budget, Mid-Range, Premium, Luxury
   */
  async getHotelDetailsByQuoteIdFromTbo(
    quoteId: string,
    page?: number,
    pageSize?: number,
    groupType?: number,
    itineraryRouteId?: number,
  ): Promise<ItineraryHotelDetailsResponseDto> {
    const startTime = Date.now();
    this.logger.log(`\n📡 TBO HOTEL PACKAGES: Fetching dynamic packages for quote: ${quoteId}`);

    const hasCompatibilityFilters =
      page !== undefined ||
      pageSize !== undefined ||
      groupType !== undefined ||
      itineraryRouteId !== undefined;

    const cached = this.getCachedHotelDetails(quoteId);
    if (cached) {
      return hasCompatibilityFilters
        ? this.applyCompatibilityFilters(
            cached,
            page,
            pageSize,
            groupType,
            itineraryRouteId,
          )
        : cached;
    }

    // Step 1: Get itinerary plan
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_quote_ID: quoteId, deleted: 0 },
    });

    if (!plan) {
      this.logger.warn(`⚠️  Quote ID not found: ${quoteId}`);
      throw new NotFoundException('Itinerary not found');
    }

    const planId = plan.itinerary_plan_ID;
    const guestNationality = await this.resolveGuestNationality(plan);
    this.logger.log(`✅ Found plan ID: ${planId}`);

    // Step 2: Get itinerary routes (days and destinations)
    const routes = await this.prisma.dvi_itinerary_route_details.findMany({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      orderBy: { itinerary_route_date: 'asc' },
    });

    this.logger.log(`📅 Routes Query Result: ${JSON.stringify({
      total: routes.length,
      routes: routes.map(r => ({ id: (r as any).itinerary_route_ID, location: (r as any).location_name, date: (r as any).itinerary_route_date }))
    })}`);

    if (routes.length === 0) {
      this.logger.warn(`⚠️  No routes found for plan ${planId}`);
      throw new BadRequestException('Itinerary has no routes');
    }

    this.logger.log(`📅 Found ${routes.length} routes to process`);

    // Get number of nights from plan to determine which routes need hotels
    const noOfNights = Number((plan as any).no_of_nights || 0);
    this.logger.log(`🌙 Plan has ${noOfNights} nights`);

    // Read pax counts saved by the user when creating the itinerary
    const planRoomCount = Math.max(Number((plan as any).preferred_room_count || 1), 1);
    const planAdultCount = Number((plan as any).total_adult || 0);
    const planChildCount = Number((plan as any).total_children || 0);
    this.logger.log(
      `👥 Pax from plan: rooms=${planRoomCount}, adults=${planAdultCount}, children=${planChildCount}`,
    );

    // Fetch child ages from saved travellers so the TBO search uses actual ages, not defaults.
    let planChildAges: number[] = [];
    if (planChildCount > 0) {
      const childTravellers = await this.prisma.dvi_itinerary_traveller_details.findMany({
        where: { itinerary_plan_ID: planId, traveller_type: 2, deleted: 0 },
        orderBy: { traveller_details_ID: 'asc' },
      });
      planChildAges = childTravellers
        .map((t) => Math.trunc(Number((t as any).traveller_age)))
        .filter((age) => Number.isFinite(age) && age >= 0 && age <= 11);
      this.logger.log(`👦 Child ages from travellers: [${planChildAges.join(', ')}]`);
    }

    // Step 3: Fetch hotels from TBO for each route (except last route if it's departure day)
    const hotelsByRoute = await this.fetchHotelsForRoutesWithRetry(
      routes,
      noOfNights,
      guestNationality,
      planRoomCount,
      planAdultCount,
      planChildCount,
      planChildAges,
    );
    
    // Step 3.5: Fetch HOBSE hotels and merge with TBO hotels
    // First, create a HOBSE-specific city code map using hobse_city_code
    const hobseCityCodeMap = await this.batchMapDestinationsToHobseCityCodes(routes);
    const hobseHotelsByRoute = await this.fetchHobseHotelsForRoutes(routes, noOfNights, hobseCityCodeMap);
    
    // Merge HOBSE hotels into the TBO hotel map
    hobseHotelsByRoute.forEach((hobseHotels, routeId) => {
      const existingHotels = hotelsByRoute.get(routeId) || [];
      hotelsByRoute.set(routeId, [...existingHotels, ...hobseHotels]);
    });

    // Step 3.6: Fetch ResAvenue hotels explicitly (in case they weren't included in TBO search)
    const resavenueHotelsByRoute = await this.fetchResavenueHotelsForRoutes(
      routes,
      noOfNights,
      guestNationality,
      planRoomCount,
      planAdultCount,
      planChildCount,
    );
    
    // Merge ResAvenue hotels into the hotel map
    resavenueHotelsByRoute.forEach((resavenueHotels, routeId) => {
      const existingHotels = hotelsByRoute.get(routeId) || [];
      // Avoid duplicates: check if hotel already exists by hotel code + provider
      const hotelStrs = existingHotels.map(h => `${h.hotelCode}|${h.provider}`);
      const newHotels = resavenueHotels.filter(h => !hotelStrs.includes(`${h.hotelCode}|${h.provider}`));
      if (newHotels.length > 0) {
        this.logger.log(`   ✅ Added ${newHotels.length} new ResAvenue hotel(s) to route ${routeId}`);
      }
      hotelsByRoute.set(routeId, [...existingHotels, ...newHotels]);
    });
    
    // Debug: Check if any hotels were found
    const hotelEntries = Array.from(hotelsByRoute.entries());
    this.logger.log(`\n📊 HOTEL FETCH RESULTS (TBO + HOBSE):`);
    hotelEntries.forEach(([routeId, hotels]) => {
      const tboCount = hotels.filter(h => h.provider === 'tbo').length;
      const hobseCount = hotels.filter(h => h.provider === 'hobse').length;
      this.logger.log(`   Route ${routeId}: ${hotels.length} hotels (TBO: ${tboCount}, HOBSE: ${hobseCount})`);
      if (hotels.length > 0) {
     //   this.logger.log(`      - ${hotels.map(h => `${h.hotelName} (${h.provider})`).join(', ')}`);
      }
    });
    
    if (hotelEntries.every(([_, hotels]) => hotels.length === 0)) {
      this.logger.warn(`\n❌ WARNING: ALL ROUTES RETURNED ZERO HOTELS!\n`);
    }
    
   // this.logger.log(`🏨 Hotels by Route: ${JSON.stringify(Object.fromEntries(hotelsByRoute))}`);

    // Step 4: Generate 4 price tier packages
    const packages = this.generatePricePackages(hotelsByRoute, routes);

    // Step 5: Build response
    const response = await this.buildHotelDetailsResponse(
      quoteId,
      planId,
      packages,
      hotelsByRoute,
      routes,
      noOfNights,
    );

    const duration = Date.now() - startTime;
    this.logger.log(`✅ Generated ${packages.length} hotel packages`);
    this.logger.log(`⏱️  Total TBO Service Time: ${duration}ms\n`);

    this.setCachedHotelDetails(quoteId, response);

    return hasCompatibilityFilters
      ? this.applyCompatibilityFilters(
          response,
          page,
          pageSize,
          groupType,
          itineraryRouteId,
        )
      : response;
  }

  // Backward-compatible alias used by older controllers/callers.
  clearHotelCacheForQuote(quoteId: string): void {
    this.clearCacheForQuote(quoteId);
  }

  private applyCompatibilityFilters(
    response: ItineraryHotelDetailsResponseDto,
    page?: number,
    pageSize?: number,
    groupType?: number,
    itineraryRouteId?: number,
  ): ItineraryHotelDetailsResponseDto {
    const normalizedGroupType = Number.isFinite(Number(groupType))
      ? Number(groupType)
      : undefined;
    const normalizedRouteId = Number.isFinite(Number(itineraryRouteId))
      ? Number(itineraryRouteId)
      : undefined;

    let filteredHotels = [...(response.hotels || [])];
    if (normalizedGroupType && normalizedGroupType >= 1 && normalizedGroupType <= 4) {
      filteredHotels = filteredHotels.filter((h) => Number(h.groupType) === normalizedGroupType);
    }
    if (normalizedRouteId && normalizedRouteId > 0) {
      filteredHotels = filteredHotels.filter((h) => Number(h.itineraryRouteId) === normalizedRouteId);
    }

    return {
      ...response,
      hotels: filteredHotels,
      pagination: undefined,
      routePagination: undefined,
    };
  }

  /**
   * Fetch available hotels from TBO for each route with OPTIMIZED city mapping
   * Uses batch city lookup and parallel processing instead of sequential queries
   */
  private async fetchHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
    childAges: number[] = [],
  ): Promise<Map<number, HotelSearchResult[] | null>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[] | null>();

    // 🔥 OPTIMIZATION 1: Batch load ALL cities upfront instead of querying per route
    const cityCodeMap = await this.batchMapDestinationsToCityCodes(routes);
    this.logger.log(`✅ Pre-loaded ${Object.keys(cityCodeMap).length} city codes for all routes`);

    // Build stay blocks so TBO search is done once per destination-stay window,
    // not once per day/route.
    const stayBlocks = this.buildStayBlocks(routes, noOfNights);
    this.logger.log(`🧩 Built ${stayBlocks.length} stay block(s) for consolidated TBO search`);

    // 🔥 OPTIMIZATION 2: Prepare all hotel search tasks for parallel execution
    const searchTasks: Promise<void>[] = [];

    for (const block of stayBlocks) {
      searchTasks.push(
        this.searchHotelsForStayBlock(
          block,
          cityCodeMap,
          guestNationality,
          roomCount,
          adultCount,
          childCount,
          childAges,
        )
          .then((hotels) => {
            block.routeIds.forEach((routeId) => hotelsByRoute.set(routeId, hotels || []));
          })
          .catch((error) => {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(
              `❌ HOTEL SEARCH ERROR for stay block ${block.destination} (${block.checkInDate} -> ${block.checkOutDate}): ${errorMsg}`,
            );
            block.routeIds.forEach((routeId) => hotelsByRoute.set(routeId, null)); // null = provider failure
          }),
      );
    }

    // 🔥 OPTIMIZATION 3: Execute all searches in parallel instead of sequentially
    this.logger.log(`⏳ Starting ${searchTasks.length} parallel hotel searches...`);
    await Promise.all(searchTasks);
    this.logger.log(`✅ All parallel searches completed`);

    return hotelsByRoute;
  }

  private buildStayBlocks(
    routes: any[],
    noOfNights: number,
  ): Array<{
    destination: string;
    checkInDate: string;
    checkOutDate: string;
    routeIds: number[];
  }> {
    const blocks: Array<{
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
    }> = [];

    const totalRoutes = routes.length;
    let currentBlock: {
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
      lastDate: Date;
    } | null = null;

    for (let routeIndex = 0; routeIndex < routes.length; routeIndex++) {
      const route = routes[routeIndex];
      const isLastRoute = routeIndex === totalRoutes - 1;
      if (isLastRoute && routeIndex >= noOfNights) {
        this.logger.log(`   ⏭️  Skipping route ${routeIndex + 1} (last route - departure day, no hotel needed)`);
        continue;
      }

      const routeId = Number((route as any).itinerary_route_ID);
      const destination = String((route as any).next_visiting_location || '').trim();
      const routeDate = new Date((route as any).itinerary_route_date);
      const checkInDate = routeDate.toISOString().split('T')[0];
      const nextDay = new Date(routeDate.getTime() + ItineraryHotelDetailsTboService.ONE_DAY_MS);
      const checkOutDate = nextDay.toISOString().split('T')[0];

      if (!currentBlock) {
        currentBlock = {
          destination,
          checkInDate,
          checkOutDate,
          routeIds: [routeId],
          lastDate: routeDate,
        };
        continue;
      }

      const isSameDestination = destination === currentBlock.destination;
      const isConsecutiveDay =
        routeDate.getTime() - currentBlock.lastDate.getTime() === ItineraryHotelDetailsTboService.ONE_DAY_MS;

      if (isSameDestination && isConsecutiveDay) {
        currentBlock.checkOutDate = checkOutDate;
        currentBlock.routeIds.push(routeId);
        currentBlock.lastDate = routeDate;
      } else {
        blocks.push({
          destination: currentBlock.destination,
          checkInDate: currentBlock.checkInDate,
          checkOutDate: currentBlock.checkOutDate,
          routeIds: currentBlock.routeIds,
        });
        currentBlock = {
          destination,
          checkInDate,
          checkOutDate,
          routeIds: [routeId],
          lastDate: routeDate,
        };
      }
    }

    if (currentBlock) {
      blocks.push({
        destination: currentBlock.destination,
        checkInDate: currentBlock.checkInDate,
        checkOutDate: currentBlock.checkOutDate,
        routeIds: currentBlock.routeIds,
      });
    }

    return blocks;
  }

  /**
   * Batch load city codes for all destinations in one pass
   * Reduces database queries from N×3 (N routes × 3 attempts) to 1 query
   */
  private async batchMapDestinationsToCityCodes(routes: any[]): Promise<Record<string, string>> {
    const cityCodeMap: Record<string, string> = {};
    
    // Extract unique destinations from all routes
    const uniqueDestinations = [...new Set(routes.map(r => (r as any).next_visiting_location))];
    this.logger.log(`📍 Extracting city codes for ${uniqueDestinations.length} unique destinations`);

    if (uniqueDestinations.length === 0) return cityCodeMap;

    // ⚡ Load ALL cities from database in ONE query instead of per-route queries
    const allCities = await this.prisma.dvi_cities.findMany({
      select: { name: true, tbo_city_code: true },
    });
    this.logger.log(`✅ Loaded ${allCities.length} cities from database in single query`);

    // Build a map for fast lookup
    const cityNameMap: Record<string, string> = {};
    const cityPrefixMap: Record<string, string> = {};
    
    allCities.forEach(city => {
      if (city.tbo_city_code) {
        cityNameMap[city.name.toLowerCase()] = city.tbo_city_code;
        const prefix = city.name.split(',')[0].trim().toUpperCase();
        cityPrefixMap[prefix] = city.tbo_city_code;
      }
    });

    // Map each destination to city code
    uniqueDestinations.forEach(destination => {
      if (!destination) return;

      // Try exact match (case-insensitive)
      let cityCode = cityNameMap[destination.toLowerCase()];
      
      if (!cityCode) {
        // Try partial match with first part
        const firstPart = destination.split(',')[0].trim();
        cityCode = cityNameMap[firstPart.toLowerCase()];
      }

      if (!cityCode) {
        // Try prefix match
        const prefix = destination.split(',')[0].trim().toUpperCase();
        cityCode = cityPrefixMap[prefix];
      }

      if (cityCode) {
        this.logger.log(`✅ "${destination}" → TBO Code: ${cityCode}`);
        cityCodeMap[destination] = cityCode;
      } else {
        this.logger.warn(`❌ No city code found for: "${destination}"`);
      }
    });

    return cityCodeMap;
  }

  /**
     * Batch load HOBSE city codes for all destinations using hobse_city_code field.
     */
    private async batchMapDestinationsToHobseCityCodes(routes: any[]): Promise<Record<string, string>> {
      const cityCodeMap: Record<string, string> = {};
      const uniqueDestinations = [...new Set(routes.map(r => (r as any).next_visiting_location))] as string[];

      this.logger.log(`📍 Loading HOBSE city codes for ${uniqueDestinations.length} unique destinations`);
      if (uniqueDestinations.length === 0) return cityCodeMap;

      const allCities = await this.prisma.dvi_cities.findMany({
        select: { name: true, hobse_city_code: true } as any,
      });
      this.logger.log(`✅ Loaded ${allCities.length} cities for HOBSE code lookup`);

      const cityNameMap: Record<string, string> = {};
      const cityPrefixMap: Record<string, string> = {};

      allCities.forEach((city: any) => {
        if (city.hobse_city_code) {
          cityNameMap[city.name.toLowerCase()] = String(city.hobse_city_code);
          const prefix = city.name.split(',')[0].trim().toLowerCase();
          cityPrefixMap[prefix] = String(city.hobse_city_code);
        }
      });

      uniqueDestinations.forEach(destination => {
        if (!destination) return;
        const lower = destination.toLowerCase();
        let code = cityNameMap[lower];

        if (!code) {
          const firstPart = destination.split(/[,\(\-]/)[0].trim().toLowerCase();
          code = cityNameMap[firstPart] || cityPrefixMap[firstPart];
        }

        if (code) {
          this.logger.log(`✅ HOBSE "${destination}" -> code: ${code}`);
          cityCodeMap[destination] = code;
        } else {
          this.logger.warn(`❌ No HOBSE city code found for: "${destination}"`);
        }
      });

      return cityCodeMap;
  }

  /**
   * Search hotels for a single route (used in parallel execution)
   */
  private async searchHotelsForStayBlock(
    block: {
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
    },
    cityCodeMap: Record<string, string>,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
    childAges: number[] = [],
  ): Promise<HotelSearchResult[]> {
    const destination = block.destination;

    this.logger.log(
      `🔍 Stay block (${block.routeIds.join(',')}): Searching hotels for "${destination}" (${block.checkInDate} -> ${block.checkOutDate})`,
    );

    // Get city code from pre-loaded map (no database query!)
    const cityCode = cityCodeMap[destination];

    // Fallback: if dvi_cities mapping is missing, use destination text directly.
    const effectiveCityCode = cityCode || destination;
    if (!cityCode) {
      this.logger.warn(
        `⚠️ Stay block (${block.routeIds.join(',')}): No mapped TBO city code for "${destination}". Falling back to destination text lookup.`,
      );
    }

    // Use pax counts from the plan; guarantee at least 1 adult so TBO validation passes
    if (adultCount <= 0) {
      this.logger.warn(
        `⚠️ Stay block (${block.routeIds.join(',')}): adultCount is ${adultCount} (not saved in plan?) - defaulting to 1`,
      );
    }
    const safeAdultCount = adultCount > 0 ? adultCount : 1;
    const safeChildCount = childCount >= 0 ? childCount : 0;
    const guestCount = safeAdultCount + safeChildCount;
    const safeRoomCount = Math.max(Number(roomCount || 1), 1);

    const searchCriteria = {
      cityCode: effectiveCityCode,
      checkInDate: block.checkInDate,
      checkOutDate: block.checkOutDate,
      roomCount: safeRoomCount,
      guestCount,
      adultCount: safeAdultCount,
      childCount: safeChildCount,
      childAges: childAges.length > 0 ? childAges : undefined,
      guestNationality,
      providers: ['tbo', 'resavenue'], // Only TBO + ResAvenue - HOBSE will be merged separately
    };

    this.logger.log(
      `   🏨 Searching hotels with cityCode: ${effectiveCityCode}, checkIn: ${block.checkInDate}, checkOut: ${block.checkOutDate}`,
    );
    const hotels = await this.hotelSearchService.searchHotels(searchCriteria);
    this.logger.log(
      `   ✅ Found ${hotels ? hotels.length : 0} hotels for stay block (${block.routeIds.join(',')}) (TBO only at this stage)`,
    );
    
    if (hotels && hotels.length > 0) {
      this.logger.log(`   📋 TBO Hotels for stay block (${block.routeIds.join(',')}):`);
      hotels.forEach((h, idx) => {
      //  this.logger.log(`      ${idx + 1}. ${h.hotelName} (${h.provider}) - ₹${h.price}`);
      });
    } else {
      this.logger.log(`   ⚠️  WARNING: TBO search returned ZERO hotels for stay block (${block.routeIds.join(',')})!`);
    }

    return hotels || [];
  }

  /**
   * Fetch HOBSE hotels for each route
   * Maps destinations to HOBSE city codes and calls HOBSE provider
   */
  private async fetchHobseHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    cityCodeMap: Record<string, string>,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    const totalRoutes = routes.length;

    this.logger.log(`\n🏨 HOBSE HOTEL FETCH: Attempting to fetch HOBSE hotels for ${routes.length} routes`);

    try {
      for (let routeIndex = 0; routeIndex < routes.length; routeIndex++) {
        const route = routes[routeIndex];
        const routeId = (route as any).itinerary_route_ID;
        
        // Skip hotel generation for the last route (departure day) if routeIndex >= noOfNights
        const isLastRoute = routeIndex === totalRoutes - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   ⏭️  Skipping HOBSE route ${routeIndex + 1} (last route - departure day)`);
          continue;
        }
        
        const destination = (route as any).next_visiting_location;
        // Get the HOBSE city code from the pre-built map
        const cityCode = cityCodeMap[destination];
        
        if (!cityCode) {
          this.logger.warn(`   ⚠️  No HOBSE city code for destination "${destination}" - skipping HOBSE search`);
          hotelsByRoute.set(routeId, []);
          continue;
        }
        const routeDate = new Date((route as any).itinerary_route_date);
        const checkOutDate = new Date(routeDate);
        checkOutDate.setDate(checkOutDate.getDate() + 1);

        try {
          // Pass city code (number) instead of destination name (string)
          const hobseHotels = await this.hobseProvider.search({
            cityCode: cityCode,
            checkInDate: routeDate.toISOString().split('T')[0],
            checkOutDate: checkOutDate.toISOString().split('T')[0],
            roomCount: 1,
            guestCount: 2,
          });

          if (hobseHotels && hobseHotels.length > 0) {
            this.logger.log(`   ✅ HOBSE Route ${routeId}: Found ${hobseHotels.length} hotels in ${destination}`);
            hotelsByRoute.set(routeId, hobseHotels);
          } else {
            this.logger.log(`   ℹ️  HOBSE Route ${routeId}: No hotels found in ${destination}`);
            hotelsByRoute.set(routeId, []);
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          this.logger.warn(`   ⚠️  HOBSE Route ${routeId} search failed: ${errorMsg}`);
          hotelsByRoute.set(routeId, []);
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.logger.error(`❌ HOBSE HOTEL FETCH FAILED: ${errorMsg}`);
    }

    return hotelsByRoute;
  }

  /**
   * Fetch ResAvenue hotels for each route
   * Searches for properties using destination city names
   */
  private async fetchResavenueHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    const totalRoutes = routes.length;

    this.logger.log(`\n🏨 RESAVENUE HOTEL FETCH: Attempting to fetch ResAvenue hotels for ${routes.length} routes`);

    try {
      const safeAdultCount = adultCount > 0 ? adultCount : 1;
      const safeChildCount = childCount >= 0 ? childCount : 0;
      const safeRoomCount = Math.max(Number(roomCount || 1), 1);
      const guestCount = safeAdultCount + safeChildCount;

      for (let routeIndex = 0; routeIndex < totalRoutes; routeIndex++) {
        const route = routes[routeIndex];
        const routeId = (route as any).itinerary_route_ID;
        
        // Skip hotel generation for the last route (departure day) if routeIndex >= noOfNights
        const isLastRoute = routeIndex === totalRoutes - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   ⏭️  Skipping ResAvenue route ${routeIndex + 1} (last route - departure day)`);
          continue;
        }
        
        const destination = (route as any).next_visiting_location;
        const routeDate = new Date((route as any).itinerary_route_date);
        const checkOutDate = new Date(routeDate);
        checkOutDate.setDate(checkOutDate.getDate() + 1);

        try {
          // Search ResAvenue hotels using city name directly
          const resavenueHotels = await this.hotelSearchService.searchHotels({
            cityCode: destination, // ResAvenue provider accepts city names
            checkInDate: routeDate.toISOString().split('T')[0],
            checkOutDate: checkOutDate.toISOString().split('T')[0],
            roomCount: safeRoomCount,
            guestCount,
            adultCount: safeAdultCount,
            childCount: safeChildCount,
            guestNationality,
            providers: ['resavenue'], // Only ResAvenue
          });

          if (resavenueHotels && resavenueHotels.length > 0) {
            this.logger.log(`   ✅ ResAvenue Route ${routeId}: Found ${resavenueHotels.length} hotels in ${destination}`);
            hotelsByRoute.set(routeId, resavenueHotels);
          } else {
            this.logger.log(`   ℹ️  ResAvenue Route ${routeId}: No hotels found in ${destination}`);
            hotelsByRoute.set(routeId, []);
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          this.logger.warn(`   ⚠️  ResAvenue Route ${routeId} search failed: ${errorMsg}`);
          hotelsByRoute.set(routeId, []);
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.logger.error(`❌ RESAVENUE HOTEL FETCH FAILED: ${errorMsg}`);
    }

    return hotelsByRoute;
  }


  private generatePricePackages(
    hotelsByRoute: Map<number, HotelSearchResult[]>,
    routes: any[],
  ): Array<{ groupType: number; label: string; hotels: Array<HotelSearchResult & { routeId: number }> }> {
    const packages: Array<{
      groupType: number;
      label: string;
      hotels: Array<HotelSearchResult & { routeId: number }>;
    }> = [];

    const labels = [
      'Budget Hotels',
      'Mid-Range Hotels',
      'Premium Hotels',
      'Luxury Hotels',
    ];

    // Debug: Log all available hotels
    this.logger.log(`\n   📊 PRICE TIER GENERATION DEBUG (PER-DESTINATION):`);
    this.logger.log(`   Total routes: ${routes.length}`);
    hotelsByRoute.forEach((hotels, routeId) => {
      const prices = hotels.map(h => h.price).join(', ');
      this.logger.log(`   Route ${routeId}: ${hotels.length} hotels (Prices: ${prices})`);
    });

    // NEW LOGIC: Assign hotels to groups PER DESTINATION (per route)
    // Rule: If 1 hotel -> put in all 4 groups
    //       If 2+ hotels -> distribute in ascending price order across groups
    
    // First pass: Determine groupType for each hotel based on its destination
    const hotelGroupAssignments = new Map<string, number>(); // key: "routeId-hotelCode" -> groupType
    
    for (const route of routes) {
      const routeId = (route as any).itinerary_route_ID;
      const availableHotels = hotelsByRoute.get(routeId);

      if (availableHotels === null) {
        this.logger.warn(`      🚨 Provider/system failure for route ${routeId} — skipping placeholder row. See previous logs for error.`);
        continue;
      }
      if (!Array.isArray(availableHotels) || availableHotels.length === 0) {
        this.logger.warn(`      ⚠️  No hotels available for route ${routeId}`);
        continue;
      }

      // Sort hotels by price (ascending) for this destination
      const sortedHotels = [...availableHotels].sort((a, b) => a.price - b.price);

      if (sortedHotels.length === 1) {
        // Single hotel: assign to ALL 4 groups
        const hotel = sortedHotels[0];
        for (let groupType = 1; groupType <= 4; groupType++) {
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          hotelGroupAssignments.set(`${key}:${groupType}`, groupType);
        }
        this.logger.debug(`   Route ${routeId}: 1 hotel - "${hotel.hotelName}" (₹${hotel.price}) assigned to ALL groups`);
      } else {
        // Multiple hotels: distribute across groups by price order
        const numHotels = sortedHotels.length;
        const groupsNeeded = Math.min(numHotels, 4);
        
        sortedHotels.forEach((hotel, index) => {
          // Map hotels to groups in ascending price order
          let groupType = 1;
          if (numHotels <= 4) {
            // Fewer hotels than groups: distribute evenly
            groupType = Math.min(index + 1, 4);
          } else {
            // More hotels than groups: distribute proportionally
            groupType = Math.floor((index / numHotels) * 4) + 1;
            groupType = Math.min(groupType, 4);
          }
          
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          hotelGroupAssignments.set(`${key}:${groupType}`, groupType);
        });
        
        this.logger.debug(`   Route ${routeId}: ${numHotels} hotels - Distributed across groups by price order`);
        sortedHotels.forEach((h, i) => {
          const key = `${routeId}-${h.hotelCode || h.hotelName}`;
          let groupType = 1;
          if (numHotels <= 4) {
            groupType = Math.min(i + 1, 4);
          } else {
            groupType = Math.floor((i / numHotels) * 4) + 1;
            groupType = Math.min(groupType, 4);
          }
       //   this.logger.debug(`      "${h.hotelName}" (₹${h.price}) -> Group ${groupType}`);
        });
      }
    }

    // Second pass: Build packages from the assignments
    for (let tier = 0; tier < 4; tier++) {
      const groupType = tier + 1;
      const tieredHotels: Array<HotelSearchResult & { routeId: number }> = [];

      for (const route of routes) {
        const routeId = (route as any).itinerary_route_ID;
        const availableHotels = hotelsByRoute.get(routeId);

        if (availableHotels === null) {
          this.logger.warn(`   🚨 Provider/system failure for route ${routeId} — not inserting placeholder row. See previous logs for error.`);
          continue;
        }
        if (!Array.isArray(availableHotels) || availableHotels.length === 0) {
          this.logger.debug(`   Tier ${groupType}, Route ${routeId}: No hotels available`);
          // CREATE PLACEHOLDER FOR NO HOTELS - price 0
          const placeholderHotel: any = {
            hotelCode: '0',
            hotelName: 'No Hotels Available',
            roomType: '-',
            mealPlan: '-',
            price: 0,
            rating: 0,
            routeId: routeId
          };
          tieredHotels.push(placeholderHotel);
          continue;
        }

        let foundForGroup = false;

        // Get hotels that belong to this tier for this route
        for (const hotel of availableHotels) {
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          const assignedGroupType = hotelGroupAssignments.get(`${key}:${groupType}`);
          
          if (assignedGroupType === groupType) {
            const hotelWithRoute = { ...hotel, routeId } as HotelSearchResult & { routeId: number };
            tieredHotels.push(hotelWithRoute);
            foundForGroup = true;
          }
        }

        // Overlap fallback: if this route has hotels but none mapped to current tier,
        // pick deterministic fallback by sorted price index so every tier has data.
        if (!foundForGroup && availableHotels.length > 0) {
          const sortedHotels = [...availableHotels].sort((a, b) => (a.price || 0) - (b.price || 0));
          const fallbackIndex = Math.min(groupType - 1, sortedHotels.length - 1);
          const fallbackHotel = sortedHotels[fallbackIndex];
          if (fallbackHotel) {
            const fallbackWithRoute = {
              ...fallbackHotel,
              routeId,
              __fallbackAssigned: true,
            } as HotelSearchResult & { routeId: number };
            tieredHotels.push(fallbackWithRoute);
            this.logger.debug(
              `   Tier ${groupType}, Route ${routeId}: overlap fallback -> ${fallbackHotel.hotelName}`,
            );
          }
        }
      }

      // Add package with ALL matching hotels for this tier
      if (tieredHotels.length > 0) {
        const totalPrice = tieredHotels.reduce((sum, h) => sum + h.price, 0);
        packages.push({
          groupType: groupType,
          label: labels[tier],
          hotels: tieredHotels,
        });
        this.logger.log(`   ✅ Group ${groupType} (${labels[tier]}): ${tieredHotels.length} hotels total, ₹${totalPrice} combined`);
      } else {
        this.logger.log(`   ⚠️  Group ${groupType} (${labels[tier]}): No hotels found for any route`);
      }
    }

    this.logger.log(`📦 Generated ${packages.length} price tier packages\n`);
    return packages;
  }

  /**
   * Build the response DTO
   */
  private async buildHotelDetailsResponse(
    quoteId: string,
    planId: number,
    packages: Array<{ groupType: number; label: string; hotels: Array<HotelSearchResult & { routeId: number }> }>,
    hotelsByRoute: Map<number, HotelSearchResult[]>,
    routes: any[],
    noOfNights: number,
  ): Promise<ItineraryHotelDetailsResponseDto> {
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      select: { hotel_rates_visibility: true },
    });

    const hotelRatesVisible =
      Number((plan as any)?.hotel_rates_visibility || 0) === 1 ||
      (plan as any)?.hotel_rates_visibility === true;

    // Build hotel tabs (one per package with total cost)
    const hotelTabs: ItineraryHotelTabDto[] = packages.map((pkg) => {
      const totalAmount = pkg.hotels.reduce((sum, h) => sum + h.price, 0);
      return {
        groupType: pkg.groupType,
        label: pkg.label,
        totalAmount,
      };
    });

    // Fetch all hotel details from database to get IDs and voucher status
    const hotelDetailsInDb = await this.prisma.dvi_itinerary_plan_hotel_details.findMany({
      where: { itinerary_plan_id: planId, deleted: 0 },
      select: {
        itinerary_plan_hotel_details_ID: true,
        itinerary_route_id: true,
        hotel_id: true,
        group_type: true,
      },
    });

    // Fetch voucher cancellation statuses
    const hotelDetailsIds = hotelDetailsInDb.map(h => h.itinerary_plan_hotel_details_ID);
    const voucherStatuses = hotelDetailsIds.length > 0
      ? await this.prisma.dvi_confirmed_itinerary_plan_hotel_voucher_details.findMany({
          where: {
            itinerary_plan_id: planId,
            itinerary_plan_hotel_details_ID: { in: hotelDetailsIds },
            deleted: 0,
          },
          select: {
            itinerary_plan_hotel_details_ID: true,
            hotel_voucher_cancellation_status: true,
          },
        })
      : [];

    // Create maps for quick lookup
    const detailsMap = new Map(
      hotelDetailsInDb.map(d => [
        `${d.itinerary_route_id}-${d.hotel_id}-${d.group_type}`,
        d.itinerary_plan_hotel_details_ID
      ])
    );
    
    const voucherStatusMap = new Map(
      voucherStatuses.map(v => [
        v.itinerary_plan_hotel_details_ID,
        v.hotel_voucher_cancellation_status === 1
      ])
    );

    // Preload route destination coordinates and hotel coordinates for distance calculation.
    const routeLocationIds = Array.from(
      new Set(
        routes
          .map((r: any) => Number((r as any).location_id || 0))
          .filter((id: number) => id > 0),
      ),
    );

    const storedLocations = routeLocationIds.length
      ? await this.prisma.dvi_stored_locations.findMany({
          where: { location_ID: { in: routeLocationIds }, deleted: 0 },
          select: {
            location_ID: true,
            destination_location_lattitude: true,
            destination_location_longitude: true,
          },
        })
      : [];

    const routeDestinationCoordsByLocationId = new Map<number, { lat: number; lon: number }>();
    for (const loc of storedLocations as any[]) {
      const lat = Number((loc as any).destination_location_lattitude ?? 0);
      const lon = Number((loc as any).destination_location_longitude ?? 0);
      if (Number.isFinite(lat) && Number.isFinite(lon) && lat !== 0 && lon !== 0) {
        routeDestinationCoordsByLocationId.set(Number((loc as any).location_ID), { lat, lon });
      }
    }

    const providerCodeSet = new Set<string>();
    for (const pkg of packages) {
      for (const h of pkg.hotels) {
        const provider = String((h as any).provider || 'tbo').trim().toLowerCase();
        const code = String((h as any).hotelCode || '').trim();
        if (!code) continue;
        providerCodeSet.add(`${provider}|${code}`);
      }
    }

    const tboCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('tbo|'))
      .map((k) => k.slice(4));
    const resavenueCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('resavenue|'))
      .map((k) => k.slice('resavenue|'.length));
    const hobseCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('hobse|'))
      .map((k) => k.slice(6));

    const hotelMasters = providerCodeSet.size
      ? await this.prisma.dvi_hotel.findMany({
          where: {
            OR: [
              ...(tboCodes.length
                ? [{ tbo_hotel_code: { in: tboCodes } }]
                : []),
              ...(resavenueCodes.length
                ? [{ resavenue_hotel_code: { in: resavenueCodes } }]
                : []),
              ...(hobseCodes.length
                ? [{ hotel_code: { in: hobseCodes } }]
                : []),
            ],
          },
          select: {
            tbo_hotel_code: true,
            resavenue_hotel_code: true,
            hotel_code: true,
            hotel_latitude: true,
            hotel_longitude: true,
          },
        })
      : [];

    const hotelCoordsByProviderCode = new Map<string, { lat: number; lon: number }>();
    for (const hm of hotelMasters as any[]) {
      const lat = Number((hm as any).hotel_latitude ?? 0);
      const lon = Number((hm as any).hotel_longitude ?? 0);
      if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat === 0 || lon === 0) {
        continue;
      }

      const tboCode = String((hm as any).tbo_hotel_code || '').trim();
      const resavenueCode = String((hm as any).resavenue_hotel_code || '').trim();
      const hobseCode = String((hm as any).hotel_code || '').trim();

      if (tboCode) hotelCoordsByProviderCode.set(`tbo|${tboCode}`, { lat, lon });
      if (resavenueCode) hotelCoordsByProviderCode.set(`resavenue|${resavenueCode}`, { lat, lon });
      if (hobseCode) hotelCoordsByProviderCode.set(`hobse|${hobseCode}`, { lat, lon });
    }

    // Fallback: TBO static master has wider code coverage than dvi_hotel in many environments.
    if (tboCodes.length > 0) {
      const tboMasterRows = await this.prisma.tbo_hotel_master.findMany({
        where: { tbo_hotel_code: { in: tboCodes } },
        select: {
          tbo_hotel_code: true,
          hotel_latitude: true,
          hotel_longitude: true,
        },
      });

      for (const row of tboMasterRows as any[]) {
        const code = String((row as any).tbo_hotel_code || '').trim();
        const lat = Number((row as any).hotel_latitude ?? 0);
        const lon = Number((row as any).hotel_longitude ?? 0);
        if (!code || !Number.isFinite(lat) || !Number.isFinite(lon) || lat === 0 || lon === 0) {
          continue;
        }

        const key = `tbo|${code}`;
        if (!hotelCoordsByProviderCode.has(key)) {
          hotelCoordsByProviderCode.set(key, { lat, lon });
        }
      }
    }

    // Build hotel rows (detail rows for each package)
    const hotelRows: ItineraryHotelRowDto[] = [];

    for (const pkg of packages) {
      for (const hotel of pkg.hotels) {
        // Find the route using the routeId attached to the hotel
        const route = routes.find((r: any) => r.itinerary_route_ID === hotel.routeId);
        if (!route) {
          this.logger.warn(`⚠️  Route ${hotel.routeId} not found for hotel ${hotel.hotelName}`);
          continue;
        }
        
        // Skip departure day (last route when routeIndex >= noOfNights)
        const routeIndex = routes.indexOf(route);
        const isLastRoute = routeIndex === routes.length - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   ⏭️  Skipping route ${hotel.routeId} from response (departure day)`);
          continue;
        }
        
        // Use next_visiting_location (where you're staying) for destination display
        const destination = (route as any).next_visiting_location || (route as any).location_name || '';
        
        // Use actual hotel name from TBO API response
        const displayHotelName = hotel.hotelName;
        
        // Handle both TBO (numeric) and HOBSE (UUID string) hotel codes
        const hotelId = isNaN(parseInt(hotel.hotelCode)) ? 0 : parseInt(hotel.hotelCode);
        const routeId = (route as any).itinerary_route_ID;
        const dateLabel = new Date((route as any).itinerary_route_date).toISOString().split('T')[0];
        
        // Lookup hotel details ID and voucher status (only for TBO numeric IDs)
        const lookupKey = hotelId > 0 ? `${routeId}-${hotelId}-${pkg.groupType}` : '';
        const hotelDetailsId = lookupKey ? detailsMap.get(lookupKey) : undefined;
        const voucherCancelled = hotelDetailsId ? (voucherStatusMap.get(hotelDetailsId) || false) : false;

        let hotelDistance: string | null = null;
        const routeLocationId = Number((route as any).location_id || 0);
        const routeCoords = routeDestinationCoordsByLocationId.get(routeLocationId);
        const providerCodeKey = `${String(hotel.provider || 'tbo').trim().toLowerCase()}|${String(hotel.hotelCode || '').trim()}`;
        const hotelCoords = hotelCoordsByProviderCode.get(providerCodeKey);
        if (routeCoords && hotelCoords) {
          try {
            const distanceKm = haversineKm(
              routeCoords.lat,
              routeCoords.lon,
              hotelCoords.lat,
              hotelCoords.lon,
            );
            if (Number.isFinite(distanceKm) && distanceKm > 0) {
              hotelDistance = `${distanceKm.toFixed(2)} KM`;
            }
          } catch {
            hotelDistance = null;
          }
        }

        hotelRows.push({
          groupType: pkg.groupType,
          itineraryRouteId: routeId,
          day: `Day ${routeIndex + 1} | ${dateLabel}`,
          destination: destination,
          hotelId: hotelId,
          hotelName: displayHotelName,
          category: hotel.rating ? parseInt(String(hotel.rating)) : 0,
          roomType: hotel.roomType || '',
          mealPlan: hotel.mealPlan || '-',
          totalHotelCost: Math.round(hotel.price),
          totalHotelTaxAmount: 0,
          searchReference: hotel.searchReference,
          bookingCode:
            (hotel.provider || 'tbo').toLowerCase() === 'tbo'
              ? hotel.searchReference || hotel.roomTypes?.[0]?.roomCode || undefined
              : hotel.hotelCode,
          provider: hotel.provider || 'tbo',
          voucherCancelled: voucherCancelled,
          itineraryPlanHotelDetailsId: hotelDetailsId || 0,
          date: dateLabel,
          hotelDistance,
          inclusions: hotel.inclusions && hotel.inclusions.length > 0 ? hotel.inclusions : (hotel.facilities && hotel.facilities.length > 0 ? hotel.facilities : undefined),
          amenities: hotel.amenities && hotel.amenities.length > 0 ? hotel.amenities : undefined,
          facilities: hotel.facilities && hotel.facilities.length > 0 ? hotel.facilities : undefined,
          rateConditions: hotel.rateConditions && hotel.rateConditions.length > 0 ? hotel.rateConditions : undefined,
          supplementSummary: hotel.supplementSummary,
        });

        // Log HOBSE hotel codes for debugging
        if (hotel.provider === 'HOBSE') {
          this.logger.debug(`✅ HOBSE Hotel Response: hotelCode="${hotel.hotelCode}", provider="${hotel.provider}"`);
        }
      }
    }

    const supplierHotelRows = hotelRows.filter(
      (row) => row.hotelId > 0 && row.hotelName !== 'No Hotels Available',
    );
    const placeholderRows = hotelRows.filter(
      (row) => row.hotelName === 'No Hotels Available',
    );

    const searchableRouteIds = routes
      .filter((route, index) => {
        const isLastRoute = index === routes.length - 1;
        return !(isLastRoute && index >= noOfNights);
      })
      .map((route: any) => Number(route.itinerary_route_ID));

    const totalSearchRoutes = searchableRouteIds.length;
    const emptySearchRoutes = searchableRouteIds.filter((routeId) => {
      const routeHotels = hotelsByRoute.get(routeId) || [];
      return routeHotels.length === 0;
    }).length;

    const hasSupplierHotels = supplierHotelRows.length > 0;
    const isPlaceholderOnly = !hasSupplierHotels && placeholderRows.length > 0;
    const availabilityMessage = isPlaceholderOnly
      ? 'Supplier search completed but no available rooms were returned for the selected city/date criteria.'
      : hasSupplierHotels
        ? 'Live supplier hotels are available for the current itinerary selection.'
        : 'No hotel data available yet. Try refreshing search or adjusting criteria.';

    return {
      quoteId,
      planId,
      hotelRatesVisible,
      hotelTabs,
      hotels: hotelRows,
      totalRoomCount: hotelRows.length,
      hotelAvailability: {
        hasSupplierHotels,
        supplierHotelCount: supplierHotelRows.length,
        placeholderRowCount: placeholderRows.length,
        totalSearchRoutes,
        emptySearchRoutes,
        isPlaceholderOnly,
        message: availabilityMessage,
      },
    };
  }

  /**
   * Get fresh hotel room details from TBO API (no stale data)
   * Fetches real-time data and returns in room details format
   * Uses caching by route to minimize TBO API calls within a session
   * @param quoteId - The quote ID to fetch hotel rooms for
   * @param filterRouteId - Optional: Filter results to only this route ID
   */
  async getHotelRoomDetailsFromTbo(
    quoteId: string,
    filterRouteId?: number,
  ): Promise<ItineraryHotelRoomDetailsResponseDto> {
    const startTime = Date.now();
    this.logger.log(`\n📡 FRESH ROOM DETAILS FROM TBO: Fetching live data for quote: ${quoteId}`);
    if (filterRouteId) {
      this.logger.log(`🔍 Filtering to route ID: ${filterRouteId}`);
    }

    // ✅ CHECK CACHE FIRST (per-route caching)
    const cachedResult = this.getCachedRoomDetails(quoteId, filterRouteId);
    if (cachedResult) {
      return cachedResult;
    }

    // Step 1: Get itinerary plan
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_quote_ID: quoteId, deleted: 0 },
    });

    if (!plan) {
      this.logger.warn(`⚠️  Quote ID not found: ${quoteId}`);
      throw new NotFoundException('Itinerary not found');
    }

    const planId = plan.itinerary_plan_ID;
    this.logger.log(`✅ Found plan ID: ${planId}`);

    // Step 2: Get itinerary routes (days and destinations)
    const routes = await this.prisma.dvi_itinerary_route_details.findMany({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      orderBy: { itinerary_route_date: 'asc' },
    });

    if (routes.length === 0) {
      this.logger.warn(`⚠️  No routes found for plan ${planId}`);
      throw new BadRequestException('Itinerary has no routes');
    }

    const noOfNights = Number((plan as any).no_of_nights || 0);
    this.logger.log(`🌙 Plan has ${noOfNights} nights`);

    const planRoomCount2 = Math.max(Number((plan as any).preferred_room_count || 1), 1);
    const planAdultCount2 = Number((plan as any).total_adult || 0);
    const planChildCount2 = Number((plan as any).total_children || 0);

    let planChildAges2: number[] = [];
    if (planChildCount2 > 0) {
      const childTravellers2 = await this.prisma.dvi_itinerary_traveller_details.findMany({
        where: { itinerary_plan_ID: planId, traveller_type: 2, deleted: 0 },
        orderBy: { traveller_details_ID: 'asc' },
      });
      planChildAges2 = childTravellers2
        .map((t) => Math.trunc(Number((t as any).traveller_age)))
        .filter((age) => Number.isFinite(age) && age >= 0 && age <= 11);
    }

    // Step 3: Fetch FRESH hotels from TBO
    // OPTIMIZATION: If filterRouteId provided, only fetch hotels for that specific route
    let routesToProcess = routes;
    if (filterRouteId) {
      routesToProcess = routes.filter(r => (r as any).itinerary_route_ID === filterRouteId);
      if (routesToProcess.length === 0) {
        this.logger.warn(`⚠️  Route ID ${filterRouteId} not found`);
        throw new BadRequestException(`Route ID ${filterRouteId} not found in this itinerary`);
      }
      this.logger.log(`✅ Optimized: Fetching hotels for 1 route only (filtered)`);
    }

    const guestNationality = await this.resolveGuestNationality(plan);
    const hotelsByRoute = await this.fetchHotelsForRoutes(
      routesToProcess,
      noOfNights,
      guestNationality,
      planRoomCount2,
      planAdultCount2,
      planChildCount2,
      planChildAges2,
    );

    // Step 4: Transform fresh TBO data into room details format
    const roomDetailsList: ItineraryHotelRoomDto[] = [];
    let roomDetailsId = 1;

    // Build route-scoped room candidates with group coverage fallback.
    // PHP behavior allows overlap fallback when a recommendation bucket would be empty.
    const routeHotelRows: Array<{ routeId: number; hotel: any }> = [];

    hotelsByRoute.forEach((hotelsForRoute, routeId) => {
      // FILTER: Only process this route if filterRouteId is not provided OR if it matches
      if (filterRouteId && routeId !== filterRouteId) {
        this.logger.debug(`🔍 Skipping route ${routeId} (filter: ${filterRouteId})`);
        return;
      }

      const allPrices = hotelsForRoute.map((h: HotelSearchResult) => h.price || 0);
      const sortedHotels = [...hotelsForRoute].sort((a, b) => (a.price || 0) - (b.price || 0));

      const byGroup = new Map<number, any[]>();

      hotelsForRoute.forEach((hotel: HotelSearchResult) => {
        const hotelPrice = hotel.price || 0;
        const groupType = this.getGroupTypeFromPrice(hotelPrice, allPrices);
        if (!byGroup.has(groupType)) byGroup.set(groupType, []);
        byGroup.get(groupType)!.push({ ...hotel, groupType, __fallbackAssigned: false });
      });

      // Ensure all 4 groups are represented when a route has at least one hotel.
      for (let groupType = 1; groupType <= 4; groupType++) {
        const groupHotels = byGroup.get(groupType) ?? [];
        if (groupHotels.length === 0 && sortedHotels.length > 0) {
          const fallbackIndex = Math.min(groupType - 1, sortedHotels.length - 1);
          const fallbackHotel = sortedHotels[fallbackIndex];
          if (fallbackHotel) {
            byGroup.set(groupType, [
              {
                ...fallbackHotel,
                groupType,
                __fallbackAssigned: true,
              },
            ]);
          }
        }
      }

      for (let groupType = 1; groupType <= 4; groupType++) {
        const groupHotels = byGroup.get(groupType) ?? [];
        groupHotels.forEach((hotel) => routeHotelRows.push({ routeId, hotel }));
      }
    });

    // Build room entries from fresh TBO data
    routeHotelRows.forEach(({ routeId, hotel }) => {
      const route = routes.find(r => (r as any).itinerary_route_ID === routeId);
      if (!route) return;

        // ✅ FIXED: Use actual room type from TBO, not groupType
        const firstRoomType = hotel.roomTypes?.[0];
        const actualRoomTypeId = firstRoomType?.roomTypeId || 1;
        const actualRoomTypeName = firstRoomType?.roomName || 'Standard Room';

        roomDetailsList.push({
          itineraryPlanId: planId,
          itineraryRouteId: routeId,
          itineraryPlanHotelRoomDetailsId: roomDetailsId++,
          hotelId: parseInt(hotel.hotelCode) || 0,
          hotelName: hotel.hotelName || 'Hotel',
          hotelCategory: this.getCategoryFromRating(hotel.category || hotel.rating),
          groupType: hotel.groupType || 1, // ✅ ADD: Include groupType (tier: 1-4)
          roomTypeId: actualRoomTypeId, // ✅ FIXED: Use actual TBO room type ID
          roomTypeName: actualRoomTypeName, // ✅ FIXED: Use actual TBO room type name
          roomId: parseInt(hotel.hotelCode) || 0,
          availableRoomTypes: (hotel.roomTypes || []).map((rt, idx) => ({
            roomTypeId: rt.roomTypeId || idx + 1,
            roomTypeTitle: rt.roomName,
            bookingCode: rt.roomCode,
          })),
          bookingCode: firstRoomType?.roomCode || hotel.searchReference || undefined,
          pricePerNight: Number(hotel.price || 0),
          numberOfNights: noOfNights,
          totalPrice: Number(hotel.price || 0) * noOfNights,
          currency: hotel.currency || 'INR',
          mealPlan: hotel.mealPlan || 'Not Specified',
        } as any);
    });

    const duration = Date.now() - startTime;
    this.logger.log(`✅ FRESH ROOM DETAILS GENERATED`);
    this.logger.log(`📊 Room Entries: ${roomDetailsList.length}`);
    if (filterRouteId) {
      this.logger.log(`🔍 Filter Applied: Route ID ${filterRouteId}`);
    } else {
      this.logger.log(`📅 All Routes Included`);
    }
    this.logger.log(`⏱️  Duration: ${duration}ms\n`);

    const result = {
      quoteId: (plan as any).itinerary_quote_ID ?? '',
      planId,
      rooms: roomDetailsList,
    };

    // ✅ CACHE THE RESULT for future requests
    this.setCachedRoomDetails(quoteId, result, filterRouteId);

    return result;
  }

  /**
   * Determine group type (price tier) based on hotel price relative to all hotels
   * Distributes hotels across 4 tiers: Budget (1), Mid-Range (2), Premium (3), Luxury (4)
   */
  private getGroupTypeFromPrice(
    hotelPrice: number,
    allPrices: number[]
  ): number {
    if (allPrices.length === 0) return 1;
    if (allPrices.length === 1) return 1;

    // Sort prices to find quartiles
    const sortedPrices = [...allPrices].sort((a, b) => a - b);
    
    // Calculate quartile boundaries
    const q1 = sortedPrices[Math.floor(sortedPrices.length * 0.25)];
    const q2 = sortedPrices[Math.floor(sortedPrices.length * 0.50)];
    const q3 = sortedPrices[Math.floor(sortedPrices.length * 0.75)];

    // Assign tier based on price quartile
    if (hotelPrice <= q1) return 1; // Budget (bottom 25%)
    if (hotelPrice <= q2) return 2; // Mid-Range (25-50%)
    if (hotelPrice <= q3) return 3; // Premium (50-75%)
    return 4; // Luxury (top 25%)
  }

  /**
   * Convert rating/category string to numeric category (1-4)
   */
  private getCategoryFromRating(ratingOrCategory: string | number | undefined): number {
    if (!ratingOrCategory) return 2; // Default to Mid-Range
    
    const val = typeof ratingOrCategory === 'string' 
      ? parseInt(ratingOrCategory)
      : ratingOrCategory;
    
    if (val >= 5 || val === 4) return 4; // Luxury (5-star)
    if (val === 3) return 3; // Premium (3-star equivalent)
    if (val === 2) return 2; // Mid-Range (2-star)
    return 1; // Budget
  }

  /**
   * Generate cache key for hotel room details
   * Format: "quoteId" or "quoteId:routeId" if filtered
   */
  private getCacheKey(quoteId: string, routeId?: number): string {
    if (routeId) {
      return `${quoteId}:${routeId}`;
    }
    return quoteId;
  }

  /**
   * Get cached hotel room details if available
   */
  private getCachedRoomDetails(quoteId: string, routeId?: number): ItineraryHotelRoomDetailsResponseDto | null {
    const cacheKey = this.getCacheKey(quoteId, routeId);
    const cached = this.hotelRoomDetailsCache.get(cacheKey);
    
    if (cached) {
      if (this.isCacheExpired(cached.timestamp, ItineraryHotelDetailsTboService.HOTEL_ROOM_DETAILS_CACHE_TTL_MS)) {
        this.hotelRoomDetailsCache.delete(cacheKey);
        this.logger.debug(`💾 [CACHE EXPIRED] Removed stale room cache for ${cacheKey}`);
        return null;
      }
      this.logger.log(`💾 [CACHE HIT] Using cached data for ${cacheKey}`);
      return cached.data;
    }
    
    return null;
  }

  /**
   * Store hotel room details in cache
   */
  private setCachedRoomDetails(
    quoteId: string,
    data: ItineraryHotelRoomDetailsResponseDto,
    routeId?: number,
  ): void {
    const cacheKey = this.getCacheKey(quoteId, routeId);
    this.evictOldestIfNeeded(this.hotelRoomDetailsCache);
    this.hotelRoomDetailsCache.set(cacheKey, {
      data,
      timestamp: Date.now(),
    });
    this.logger.log(`💾 [CACHE SET] Cached data for ${cacheKey}`);
  }

  private getCachedHotelDetails(quoteId: string): ItineraryHotelDetailsResponseDto | null {
    const cached = this.hotelDetailsCache.get(quoteId);
    if (!cached) {
      return null;
    }

    if (this.isCacheExpired(cached.timestamp, ItineraryHotelDetailsTboService.HOTEL_DETAILS_CACHE_TTL_MS)) {
      this.hotelDetailsCache.delete(quoteId);
      this.logger.debug(`💾 [CACHE EXPIRED] Removed stale hotel details cache for ${quoteId}`);
      return null;
    }

    this.logger.log(`💾 [CACHE HIT] Hotel details from cache for ${quoteId}`);
    return cached.data;
  }

  private setCachedHotelDetails(
    quoteId: string,
    data: ItineraryHotelDetailsResponseDto,
  ): void {
    this.evictOldestIfNeeded(this.hotelDetailsCache);
    this.hotelDetailsCache.set(quoteId, {
      data,
      timestamp: Date.now(),
    });
    this.logger.log(`💾 [CACHE SET] Hotel details cached for ${quoteId}`);
  }

  private isCacheExpired(timestamp: number, ttlMs: number): boolean {
    return Date.now() - timestamp > ttlMs;
  }

  private evictOldestIfNeeded<T extends { timestamp: number }>(cache: Map<string, T>): void {
    if (cache.size < ItineraryHotelDetailsTboService.MAX_CACHE_ENTRIES) {
      return;
    }

    let oldestKey: string | null = null;
    let oldestTs = Number.MAX_SAFE_INTEGER;

    cache.forEach((value, key) => {
      if (value.timestamp < oldestTs) {
        oldestTs = value.timestamp;
        oldestKey = key;
      }
    });

    if (oldestKey) {
      cache.delete(oldestKey);
    }
  }

  /**
   * Clear cache for a specific quote (called on refresh/update)
   * Clears both general cache (quoteId) and route-specific caches (quoteId:routeId)
   */
  clearCacheForQuote(quoteId: string): void {
    const keysToDelete: string[] = [];

    this.hotelDetailsCache.delete(quoteId);
    
    for (const key of this.hotelRoomDetailsCache.keys()) {
      if (key.startsWith(`${quoteId}:`)) { // Matches "quoteId:routeId"
        keysToDelete.push(key);
      }
    }
    
    // Also delete the base key
    keysToDelete.push(quoteId);
    
    for (const key of keysToDelete) {
      this.hotelRoomDetailsCache.delete(key);
      this.logger.log(`🗑️  [CACHE CLEARED] Removed cache for ${key}`);
    }
  }

  /**
   * Get current cache size and stats (for debugging)
   */
  getCacheStats(): { size: number; entries: string[] } {
    const detailEntries = Array.from(this.hotelDetailsCache.keys()).map((k) => `details:${k}`);
    const roomEntries = Array.from(this.hotelRoomDetailsCache.keys()).map((k) => `rooms:${k}`);

    return {
      size: this.hotelDetailsCache.size + this.hotelRoomDetailsCache.size,
      entries: [...detailEntries, ...roomEntries],
    };
  }
}

