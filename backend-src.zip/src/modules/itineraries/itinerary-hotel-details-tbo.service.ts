﻿// FILE: src/modules/itineraries/itinerary-hotel-details-tbo.service.ts

import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma.service';
import { HotelSearchService } from '../hotels/services/hotel-search.service';
import { HobseHotelProvider } from '../hotels/providers/hobse-hotel.provider';
import { HotelSearchResult } from '../hotels/interfaces/hotel-provider.interface';
import {
  ItineraryHotelTabDto,
  ItineraryHotelRowDto,
  ItineraryHotelDetailsResponseDto,
  ItineraryHotelRoomDetailsResponseDto,
  ItineraryHotelRoomDto,
} from './itinerary-hotel-details.service';
import { haversineKm } from './utils/distance-utils';
import {
  HOTEL_RATE_PLAN_BY_CODE,
  inferCanonicalHotelRatePlanCode,
  inferCanonicalHotelRatePlanCodeFromMealFlags,
  inferCanonicalHotelRatePlanCodeFromMealText,
} from '../hotels/hotel-rate-plans';

/**
 * This service generates dynamic hotel packages from TBO API
 * instead of retrieving them from the database
 */
@Injectable()
export class ItineraryHotelDetailsTboService {
  private static readonly HOTEL_DETAILS_CACHE_TTL_MS = 5 * 60 * 1000;
  private static readonly HOTEL_ROOM_DETAILS_CACHE_TTL_MS = 5 * 60 * 1000;
  private static readonly MAX_CACHE_ENTRIES = 200;

    /**
     * Fetch hotels for all routes, retrying ONCE if any provider/system failure (null) is detected.
     */
    private async fetchHotelsForRoutesWithRetry(
      routes: any[],
      noOfNights: number,
      guestNationality: string,
      roomCount: number = 1,
      adultCount: number = 2,
      childCount: number = 0,
      childAges: number[] = [],
    ): Promise<Map<number, HotelSearchResult[] | null>> {
      let hotelsByRoute = await this.fetchHotelsForRoutes(
        routes,
        noOfNights,
        guestNationality,
        roomCount,
        adultCount,
        childCount,
        childAges,
      );

      const hasProviderFailure = Array.from(hotelsByRoute.values()).some(
        (value) => value === null,
      );

      if (hasProviderFailure) {
        this.logger.warn(
          'ðŸš¨ Hotel search had provider/system failure on first attempt. Retrying once...'
        );

        // small delay to allow DB sync / provider readiness
        await new Promise((resolve) => setTimeout(resolve, 800));

        const retryResult = await this.fetchHotelsForRoutes(
          routes,
          noOfNights,
          guestNationality,
          roomCount,
          adultCount,
          childCount,
          childAges,
        );

        const retryStillFailed = Array.from(retryResult.values()).some(
          (value) => value === null,
        );

        // compare number of successful routes (non-empty arrays)
        const retrySuccessCount = Array.from(retryResult.values()).filter(
          (v) => Array.isArray(v) && v.length > 0,
        ).length;

        const firstSuccessCount = Array.from(hotelsByRoute.values()).filter(
          (v) => Array.isArray(v) && v.length > 0,
        ).length;

        this.logger.log(
          `ðŸ“Š Comparing results â†’ First: ${firstSuccessCount}, Retry: ${retrySuccessCount}`,
        );

        // return whichever has more valid hotel data
        if (retrySuccessCount >= firstSuccessCount) {
          this.logger.log('âœ… Using retry result (better or equal)');
          return retryResult;
        } else {
          this.logger.log('âš ï¸ Using first attempt result (better)');
          return hotelsByRoute;
        }
      }

      return hotelsByRoute;
    }
  private readonly logger = new Logger(ItineraryHotelDetailsTboService.name);

  private static readonly ONE_DAY_MS = 24 * 60 * 60 * 1000;

  // Cache for hotel details endpoint response (key = quoteId)
  private hotelDetailsCache = new Map<string, {
    data: ItineraryHotelDetailsResponseDto;
    timestamp: number;
  }>();
  
  // Cache structure: key = "quoteId:routeId" or "quoteId" (no route filter)
  // Stores the entire response to avoid re-fetching TBO data
  private hotelRoomDetailsCache = new Map<string, {
    data: ItineraryHotelRoomDetailsResponseDto;
    timestamp: number;
  }>();

  private isTboOnlyFetchEnabled(): boolean {
    const raw = String(process.env.HOTEL_FETCH_TBO_ONLY || '').trim().toLowerCase();
    return raw === 'true' || raw === '1' || raw === 'yes';
  }

  private isHobseSearchEnabled(): boolean {
    const raw = String(process.env.HOBSE_SEARCH_ENABLED || '0').trim().toLowerCase();
    return raw === 'true' || raw === '1' || raw === 'yes';
  }

  private normalizeNumberList(value: unknown): number[] {
    if (Array.isArray(value)) {
      return value
        .map((v) => Number(v))
        .filter((n) => Number.isFinite(n) && n > 0)
        .map((n) => Math.trunc(n));
    }

    const raw = String(value ?? '').trim();
    if (!raw) return [];

    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed
          .map((v) => Number(v))
          .filter((n) => Number.isFinite(n) && n > 0)
          .map((n) => Math.trunc(n));
      }
    } catch {
      // fall through to CSV parsing
    }

    return raw
      .split(',')
      .map((v) => Number(v.trim()))
      .filter((n) => Number.isFinite(n) && n > 0)
      .map((n) => Math.trunc(n));
  }

  private getHotelCategoryCandidates(hotel: HotelSearchResult): number[] {
    const candidates = new Set<number>();

    const ratingNum = Number((hotel as any).rating);
    if (Number.isFinite(ratingNum) && ratingNum > 0) {
      candidates.add(Math.trunc(ratingNum));
    }

    const categoryRaw = String((hotel as any).category ?? '').trim();
    if (categoryRaw) {
      const match = categoryRaw.match(/\d+/);
      if (match) {
        const categoryNum = Number(match[0]);
        if (Number.isFinite(categoryNum) && categoryNum > 0) {
          candidates.add(Math.trunc(categoryNum));
        }
      }
    }

    return Array.from(candidates);
  }

  private inferMealPlanCodeFromHotel(hotel: HotelSearchResult): string | null {
    const direct = inferCanonicalHotelRatePlanCode(String((hotel as any).mealPlan ?? ''));
    if (direct) return direct;
    return inferCanonicalHotelRatePlanCodeFromMealText(String((hotel as any).mealPlan ?? ''));
  }

  private applyPlanPreferenceFilters(
    hotelsByRoute: Map<number, HotelSearchResult[] | null>,
    preferredCategories: number[],
    preferredMealPlanCode: string | null,
  ): Map<number, HotelSearchResult[] | null> {
    const shouldFilterByCategory = preferredCategories.length > 0;
    const shouldFilterByMeal = !!preferredMealPlanCode;

    if (!shouldFilterByCategory && !shouldFilterByMeal) {
      return hotelsByRoute;
    }

    const preferredCategorySet = new Set(preferredCategories);
    const filteredMap = new Map<number, HotelSearchResult[] | null>();

    hotelsByRoute.forEach((hotels, routeId) => {
      if (!Array.isArray(hotels)) {
        filteredMap.set(routeId, hotels);
        return;
      }

      const filteredHotels = hotels.filter((hotel) => {
        let included = true;
        let filterReason = '';
        
        if (shouldFilterByCategory) {
          const categoryCandidates = this.getHotelCategoryCandidates(hotel);
          const categoryMatch = categoryCandidates.some((cat) => preferredCategorySet.has(cat));
          const isResavenueUnknownCategory =
            String((hotel as any).provider || '').toLowerCase() === 'resavenue' &&
            categoryCandidates.length === 0;

          if (!categoryMatch && !isResavenueUnknownCategory) {
            included = false;
            filterReason = `Category mismatch: ${categoryCandidates.join(',') || 'UNKNOWN'} not in ${preferredCategories.join(',')}`;
          } else if (isResavenueUnknownCategory) {
            this.logger.debug(
              `   ℹ️  Keeping ResAvenue hotel with unknown category: ${hotel.hotelName}`,
            );
          }
        }

        if (included && shouldFilterByMeal) {
          const hotelMealCode = this.inferMealPlanCodeFromHotel(hotel);
          // Only reject if hotel HAS meal plan data but it doesn't match.
          // Allow hotels that don't have meal plan data (e.g., ResAvenue).
          if (hotelMealCode && hotelMealCode !== preferredMealPlanCode) {
            included = false;
            filterReason = `Meal plan mismatch: ${hotelMealCode} != ${preferredMealPlanCode}`;
          }
        }
        
        if (!included && hotel.provider === 'resavenue') {
          this.logger.warn(`   ⚠️  Filtering out ResAvenue: ${hotel.hotelName} - Reason: ${filterReason}`);
        }
        if (!included && hotel.provider === 'staah') {
          this.logger.warn(`[STAAH FILTERED] ${hotel.hotelName} (${hotel.hotelCode}) - ${filterReason}`);
          if (String(hotel.hotelCode) === '44674') {
            const categoryCandidates = this.getHotelCategoryCandidates(hotel);
            this.logger.warn(
              `[STAAH FILTERED] STAAH TEST HOTEL removed because category ${categoryCandidates.join(',') || 'UNKNOWN'} ` +
              `not in preferred categories: ${preferredCategories.join(',') || 'ANY'}`,
            );
          }
        }

        return included;
      });

      this.logger.log(
        `   Preference filter route ${routeId}: before=${hotels.length}, after=${filteredHotels.length}, ` +
          `category=${shouldFilterByCategory ? preferredCategories.join(',') : 'ANY'}, meal=${preferredMealPlanCode || 'ANY'}`,
      );

      filteredMap.set(routeId, filteredHotels);
    });

    return filteredMap;
  }

  constructor(
    private readonly prisma: PrismaService,
    private readonly hotelSearchService: HotelSearchService,
    private readonly hobseProvider: HobseHotelProvider,
  ) {}

  private extractIso2FromCountryRow(row: any): string | null {
    if (!row || typeof row !== 'object') return null;

    const candidates = [
      row.shortname,
      row.country_code,
      row.iso2,
      row.iso_code,
      row.sortname,
      row.alpha2,
      row.code,
    ];

    for (const value of candidates) {
      const normalized = String(value ?? '').trim().toUpperCase();
      if (/^[A-Z]{2}$/.test(normalized)) {
        return normalized;
      }
    }

    return null;
  }

  // Legacy mapping: IDs 101-295 were used by the old hardcoded dropdown list.
  // These do not match dvi_countries IDs, so we map them to country names for name-based lookup.
  private static readonly LEGACY_NATIONALITY_NAME: Record<number, string> = {
    101: 'India', 102: 'Afghanistan', 103: 'Albania', 104: 'Algeria', 105: 'Andorra',
    106: 'Angola', 107: 'Antigua and Barbuda', 108: 'Argentina', 109: 'Armenia',
    110: 'Australia', 111: 'Austria', 112: 'Azerbaijan', 113: 'Bahamas', 114: 'Bahrain',
    115: 'Bangladesh', 116: 'Barbados', 117: 'Belarus', 118: 'Belgium', 119: 'Belize',
    120: 'Benin', 121: 'Bhutan', 122: 'Bolivia', 123: 'Bosnia and Herzegovina',
    124: 'Botswana', 125: 'Brazil', 126: 'Brunei', 127: 'Bulgaria', 128: 'Burkina Faso',
    129: 'Burundi', 130: 'Cabo Verde', 131: 'Cambodia', 132: 'Cameroon', 133: 'Canada',
    134: 'Central African Republic', 135: 'Chad', 136: 'Chile', 137: 'China',
    138: 'Colombia', 139: 'Comoros', 140: 'Congo', 141: 'Costa Rica', 142: 'Croatia',
    143: 'Cuba', 144: 'Cyprus', 145: 'Czech Republic',
    146: 'Democratic Republic of the Congo', 147: 'Denmark', 148: 'Djibouti',
    149: 'Dominica', 150: 'Dominican Republic', 151: 'Ecuador', 152: 'Egypt',
    153: 'El Salvador', 154: 'Equatorial Guinea', 155: 'Eritrea', 156: 'Estonia',
    157: 'Eswatini', 158: 'Ethiopia', 159: 'Fiji', 160: 'Finland', 161: 'France',
    162: 'Gabon', 163: 'Gambia', 164: 'Georgia', 165: 'Germany', 166: 'Ghana',
    167: 'Greece', 168: 'Grenada', 169: 'Guatemala', 170: 'Guinea', 171: 'Guinea-Bissau',
    172: 'Guyana', 173: 'Haiti', 174: 'Honduras', 175: 'Hungary', 176: 'Iceland',
    177: 'India', 178: 'Indonesia', 179: 'Iran', 180: 'Iraq', 181: 'Ireland',
    182: 'Israel', 183: 'Italy', 184: 'Jamaica', 185: 'Japan', 186: 'Jordan',
    187: 'Kazakhstan', 188: 'Kenya', 189: 'Kiribati', 190: 'Kuwait', 191: 'Kyrgyzstan',
    192: 'Laos', 193: 'Latvia', 194: 'Lebanon', 195: 'Lesotho', 196: 'Liberia',
    197: 'Libya', 198: 'Liechtenstein', 199: 'Lithuania', 200: 'Luxembourg',
    201: 'Madagascar', 202: 'Malawi', 203: 'Malaysia', 204: 'Maldives', 205: 'Mali',
    206: 'Malta', 207: 'Marshall Islands', 208: 'Mauritania', 209: 'Mauritius',
    210: 'Mexico', 211: 'Micronesia', 212: 'Moldova', 213: 'Monaco', 214: 'Mongolia',
    215: 'Montenegro', 216: 'Morocco', 217: 'Mozambique', 218: 'Myanmar', 219: 'Namibia',
    220: 'Nauru', 221: 'Nepal', 222: 'Netherlands', 223: 'New Zealand', 224: 'Nicaragua',
    225: 'Niger', 226: 'Nigeria', 227: 'North Korea', 228: 'North Macedonia',
    229: 'Norway', 230: 'Oman', 231: 'Pakistan', 232: 'Palau', 233: 'Panama',
    234: 'Papua New Guinea', 235: 'Paraguay', 236: 'Peru', 237: 'Philippines',
    238: 'Poland', 239: 'Portugal', 240: 'Qatar', 241: 'Romania', 242: 'Russia',
    243: 'Rwanda', 244: 'Saint Kitts and Nevis', 245: 'Saint Lucia',
    246: 'Saint Vincent and the Grenadines', 247: 'Samoa', 248: 'San Marino',
    249: 'Sao Tome and Principe', 250: 'Saudi Arabia', 251: 'Senegal', 252: 'Serbia',
    253: 'Seychelles', 254: 'Sierra Leone', 255: 'Singapore', 256: 'Slovakia',
    257: 'Slovenia', 258: 'Solomon Islands', 259: 'Somalia', 260: 'South Africa',
    261: 'South Korea', 262: 'South Sudan', 263: 'Spain', 264: 'Sri Lanka',
    265: 'Sudan', 266: 'Suriname', 267: 'Sweden', 268: 'Switzerland', 269: 'Syria',
    270: 'Taiwan', 271: 'Tajikistan', 272: 'Tanzania', 273: 'Thailand',
    274: 'Timor-Leste', 275: 'Togo', 276: 'Tonga', 277: 'Trinidad and Tobago',
    278: 'Tunisia', 279: 'Turkey', 280: 'Turkmenistan', 281: 'Tuvalu', 282: 'Uganda',
    283: 'Ukraine', 284: 'United Arab Emirates', 285: 'United Kingdom',
    286: 'United States', 287: 'Uruguay', 288: 'Uzbekistan', 289: 'Vanuatu',
    290: 'Vatican City', 291: 'Venezuela', 292: 'Vietnam', 293: 'Yemen',
    294: 'Zambia', 295: 'Zimbabwe',
  };

  private async resolveGuestNationality(plan: any): Promise<string> {
    const nationalityId = Number((plan as any)?.nationality ?? 0);
    const rawNationality = String((plan as any)?.nationality ?? '')
      .trim()
      .toUpperCase();

    // Prefer master-country mapping from DB (as requested).
    if (nationalityId > 0) {
      try {
        const country = await this.prisma.dvi_countries.findFirst({
          where: {
            id: nationalityId,
            deleted: 0,
            status: 1,
          },
          select: {
            shortname: true,
            name: true,
          },
        });
        const iso2 = this.extractIso2FromCountryRow(country);
        if (iso2) {
          this.logger.log(
            `âœ… Resolved guestNationality from country table: nationality=${nationalityId} -> ${iso2}`,
          );
          return iso2;
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        this.logger.warn(
          `âš ï¸ Could not resolve country mapping from table dvi_countries for nationality=${nationalityId}: ${message}`,
        );
      }
    }

      // Fallback: legacy hardcoded dropdown used IDs 101-295 which differ from dvi_countries IDs.
      // Resolve by looking up the country name from the legacy map and then querying dvi_countries by name.
      if (nationalityId >= 101 && nationalityId <= 295) {
        const legacyName = ItineraryHotelDetailsTboService.LEGACY_NATIONALITY_NAME[nationalityId];
        if (legacyName) {
          try {
            const countryByName = await this.prisma.dvi_countries.findFirst({
              where: { name: { contains: legacyName }, deleted: 0, status: 1 },
              select: { shortname: true, name: true },
            });
            const iso2 = this.extractIso2FromCountryRow(countryByName);
            if (iso2) {
              this.logger.log(
                `âœ… Resolved guestNationality via legacy name lookup: nationality=${nationalityId} (${legacyName}) -> ${iso2}`,
              );
              return iso2;
            }
          } catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            this.logger.warn(`âš ï¸ Legacy name lookup failed for "${legacyName}": ${msg}`);
          }
        }
      }

    // Some records may directly store ISO-2 code instead of FK id.
    if (/^[A-Z]{2}$/.test(rawNationality)) {
      this.logger.warn(
        `âš ï¸ Using direct ISO-2 nationality from plan value: ${rawNationality}`,
      );
      return rawNationality;
    }

    const envFallback = String(
      process.env.TBO_DEFAULT_GUEST_NATIONALITY || '',
    )
      .trim()
      .toUpperCase();
    if (/^[A-Z]{2}$/.test(envFallback)) {
      this.logger.warn(
        `âš ï¸ Using TBO_DEFAULT_GUEST_NATIONALITY fallback: ${envFallback}`,
      );
      return envFallback;
    }

    this.logger.warn(
      'âš ï¸ Unable to resolve guestNationality from plan/country table/env. Falling back to IN.',
    );
    return 'IN';
  }

  /**
   * Get hotel details with dynamic packages from TBO API
   * Creates 4 different price tier packages: Budget, Mid-Range, Premium, Luxury
   */
  async getHotelDetailsByQuoteIdFromTbo(
    quoteId: string,
    page?: number,
    pageSize?: number,
    groupType?: number,
    itineraryRouteId?: number,
  ): Promise<ItineraryHotelDetailsResponseDto> {
    const startTime = Date.now();
    this.logger.log(`\nðŸ“¡ TBO HOTEL PACKAGES: Fetching dynamic packages for quote: ${quoteId}`);

    const hasCompatibilityFilters =
      page !== undefined ||
      pageSize !== undefined ||
      groupType !== undefined ||
      itineraryRouteId !== undefined;

    // Step 1: Get itinerary plan
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_quote_ID: quoteId, deleted: 0 },
    });

    if (!plan) {
      this.logger.warn(`âš ï¸  Quote ID not found: ${quoteId}`);
      throw new NotFoundException('Itinerary not found');
    }

    // CACHE DISABLED - Always fetch fresh data from database
    // const cached = this.getCachedHotelDetails(quoteId);
    // if (cached) {
    //   return hasCompatibilityFilters
    //     ? this.applyCompatibilityFilters(
    //         cached,
    //         page,
    //         pageSize,
    //         groupType,
    //         itineraryRouteId,
    //       )
    //     : cached;
    // }

    const planId = plan.itinerary_plan_ID;
    const guestNationality = await this.resolveGuestNationality(plan);
    const preferredCategories = this.normalizeNumberList((plan as any).preferred_hotel_category);
    const explicitMealPlanCode = inferCanonicalHotelRatePlanCode(String((plan as any).meal_plan_code || ''));
    const mealPlanBreakfast = Number((plan as any).meal_plan_breakfast ?? 0) ? 1 : 0;
    const mealPlanLunch = Number((plan as any).meal_plan_lunch ?? 0) ? 1 : 0;
    const mealPlanDinner = Number((plan as any).meal_plan_dinner ?? 0) ? 1 : 0;
    const hasExplicitMealFlags =
      mealPlanBreakfast === 1 || mealPlanLunch === 1 || mealPlanDinner === 1;
    const fallbackMealPlanCode = hasExplicitMealFlags
      ? inferCanonicalHotelRatePlanCodeFromMealFlags(
          mealPlanBreakfast,
          mealPlanLunch,
          mealPlanDinner,
        )
      : null;
    const preferredMealPlanCode = explicitMealPlanCode || fallbackMealPlanCode;

    this.logger.log(`âœ… Found plan ID: ${planId}`);
    this.logger.log(
      `ðŸŽ›ï¸ Plan hotel prefs: categories=${preferredCategories.length ? preferredCategories.join(',') : 'ANY'}, ` +
        `mealPlan=${preferredMealPlanCode || 'ANY'}`,
    );

    // Step 2: Get itinerary routes (days and destinations)
    const routes = await this.prisma.dvi_itinerary_route_details.findMany({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      orderBy: { itinerary_route_date: 'asc' },
    });

    this.logger.log(`ðŸ“… Routes Query Result: ${JSON.stringify({
      total: routes.length,
      routes: routes.map(r => ({ id: (r as any).itinerary_route_ID, location: (r as any).location_name, date: (r as any).itinerary_route_date }))
    })}`);

    if (routes.length === 0) {
      this.logger.warn(`âš ï¸  No routes found for plan ${planId}`);
      throw new BadRequestException('Itinerary has no routes');
    }

    this.logger.log(`ðŸ“… Found ${routes.length} routes to process`);

    // Get number of nights from plan to determine which routes need hotels
    const noOfNights = Number((plan as any).no_of_nights || 0);
    this.logger.log(`ðŸŒ™ Plan has ${noOfNights} nights`);

    // Read pax counts saved by the user when creating the itinerary
    const planRoomCount = Math.max(Number((plan as any).preferred_room_count || 1), 1);
    const planAdultCount = Number((plan as any).total_adult || 0);
    const planChildCount = Number((plan as any).total_children || 0);
    this.logger.log(
      `ðŸ‘¥ Pax from plan: rooms=${planRoomCount}, adults=${planAdultCount}, children=${planChildCount}`,
    );

    // Fetch child ages from saved travellers so the TBO search uses actual ages, not defaults.
    let planChildAges: number[] = [];
    if (planChildCount > 0) {
      const childTravellers = await this.prisma.dvi_itinerary_traveller_details.findMany({
        where: { itinerary_plan_ID: planId, traveller_type: 2, deleted: 0 },
        orderBy: { traveller_details_ID: 'asc' },
      });
      planChildAges = childTravellers
        .map((t) => Math.trunc(Number((t as any).traveller_age)))
        .filter((age) => Number.isFinite(age) && age >= 0 && age <= 11);
      this.logger.log(`ðŸ‘¦ Child ages from travellers: [${planChildAges.join(', ')}]`);
    }

    // Step 3: Fetch hotels from TBO for each route (except last route if it's departure day)
    const hotelsByRoute = await this.fetchHotelsForRoutesWithRetry(
      routes,
      noOfNights,
      guestNationality,
      planRoomCount,
      planAdultCount,
      planChildCount,
      planChildAges,
    );
    
    const tboOnlyFetch = this.isTboOnlyFetchEnabled();
    if (tboOnlyFetch) {
      this.logger.warn(
        'âš ï¸ HOTEL_FETCH_TBO_ONLY enabled: skipping HOBSE/ResAvenue/AxisRooms provider fetch and returning only TBO hotels',
      );
    } else {
      if (this.isHobseSearchEnabled()) {
        // Step 3.5: Fetch HOBSE hotels and merge with TBO hotels
        // First, create a HOBSE-specific city code map using hobse_city_code
        const hobseCityCodeMap = await this.batchMapDestinationsToHobseCityCodes(routes);
        const hobseHotelsByRoute = await this.fetchHobseHotelsForRoutes(routes, noOfNights, hobseCityCodeMap);

        // Merge HOBSE hotels into the TBO hotel map
        hobseHotelsByRoute.forEach((hobseHotels, routeId) => {
          const existingHotels = hotelsByRoute.get(routeId) || [];
          hotelsByRoute.set(routeId, [...existingHotels, ...hobseHotels]);
        });
      } else {
        this.logger.warn('âš ï¸ HOBSE_SEARCH_ENABLED=0: skipping HOBSE hotel search results');
      }

      // Step 3.6: Fetch ResAvenue hotels explicitly (in case they weren't included in TBO search)
      this.logger.log(`\n🏨 STEP 3.6: Starting ResAvenue hotel fetch for ${routes.length} routes...`);
      const resavenueHotelsByRoute = await this.fetchResavenueHotelsForRoutes(
        routes,
        noOfNights,
        guestNationality,
        planRoomCount,
        planAdultCount,
        planChildCount,
      );
      
      // Debug: Check what ResAvenue returned
      let totalResavenueHotels = 0;
      resavenueHotelsByRoute.forEach((hotels, routeId) => {
        totalResavenueHotels += hotels.length;
        if (hotels.length > 0) {
          this.logger.log(`   ✅ Route ${routeId} has ${hotels.length} ResAvenue hotels: ${hotels.map(h => `${h.hotelName} (${h.hotelCode})`).join(', ')}`);
        }
      });
      this.logger.log(`🏨 ResAvenue Total: ${totalResavenueHotels} hotels across all routes`);

      // Merge ResAvenue hotels into the hotel map
      resavenueHotelsByRoute.forEach((resavenueHotels, routeId) => {
        const existingHotels = hotelsByRoute.get(routeId) || [];
        // Avoid duplicates: check if hotel already exists by hotel code + provider
        const hotelStrs = existingHotels.map(h => `${h.hotelCode}|${h.provider}`);
        const newHotels = resavenueHotels.filter(h => !hotelStrs.includes(`${h.hotelCode}|${h.provider}`));
        if (newHotels.length > 0) {
          this.logger.log(`   ✅ Added ${newHotels.length} new ResAvenue hotel(s) to route ${routeId}`);
          newHotels.forEach(h => {
            this.logger.log(`      - ${h.hotelName} (${h.hotelCode}, Category: ${h.category}, Meal: ${h.mealPlan}, Price: ₹${h.price})`);
          });
        } else if (resavenueHotels.length > 0) {
          this.logger.log(`   ℹ️  No new ResAvenue hotels (duplicates: ${resavenueHotels.length})`);
        }
        const merged = [...existingHotels, ...newHotels];
        this.logger.log(`   Route ${routeId}: Total hotels now = ${merged.length}`);
        hotelsByRoute.set(routeId, merged);
      });

      // Step 3.7: Load saved meal plans per route for AxisRooms filtering
      const savedMealPlansByRoute = await this.loadSavedMealPlansPerRoute(planId, routes);

      // Step 3.8: Fetch AxisRooms-enabled hotels from local DB and merge with existing providers.
      const axisroomsHotelsByRoute = await this.fetchAxisroomsHotelsForRoutes(
        routes,
        noOfNights,
        savedMealPlansByRoute,
        preferredMealPlanCode,
      );
      axisroomsHotelsByRoute.forEach((axisroomsHotels, routeId) => {
        const existingHotels = hotelsByRoute.get(routeId) || [];
        const hotelStrs = existingHotels.map((h) => `${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`);
        const newHotels = axisroomsHotels.filter(
          (h) => !hotelStrs.includes(`${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`),
        );
        if (newHotels.length > 0) {
          this.logger.log(`   âœ… Added ${newHotels.length} new AxisRooms hotel(s) to route ${routeId}`);
        }
        hotelsByRoute.set(routeId, [...existingHotels, ...newHotels]);
      });

      const staahHotelsByRoute = await this.fetchStaahHotelsForRoutes(
        routes,
        noOfNights,
        savedMealPlansByRoute,
        preferredMealPlanCode,
      );
      staahHotelsByRoute.forEach((staahHotels, routeId) => {
        const existingHotels = hotelsByRoute.get(routeId) || [];
        const hotelStrs = existingHotels.map((h) => `${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`);
        const newHotels = staahHotels.filter(
          (h) => !hotelStrs.includes(`${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`),
        );
        if (newHotels.length > 0) {
          this.logger.log(`   ✅ Added ${newHotels.length} new STAAH hotel(s) to route ${routeId}`);
        }
        hotelsByRoute.set(routeId, [...existingHotels, ...newHotels]);
      });
    }

    this.logger.log(`[STAAH DEBUG] Counts before preference filters:`);
    Array.from(hotelsByRoute.entries()).forEach(([routeId, hotels]) => {
      const staahCount = Array.isArray(hotels) ? hotels.filter((h) => h.provider === 'staah').length : 0;
      this.logger.log(`   Route ${routeId}: STAAH before filter = ${staahCount}`);
    });
    
    const filteredHotelsByRoute = this.applyPlanPreferenceFilters(
      hotelsByRoute,
      preferredCategories,
      preferredMealPlanCode,
    );

    this.logger.log(`[STAAH DEBUG] Counts after preference filters:`);
    Array.from(filteredHotelsByRoute.entries()).forEach(([routeId, hotels]) => {
      const staahCount = Array.isArray(hotels) ? hotels.filter((h) => h.provider === 'staah').length : 0;
      this.logger.log(`   Route ${routeId}: STAAH after filter = ${staahCount}`);
    });

    // Debug: Check if any hotels were found
    const hotelEntries = Array.from(filteredHotelsByRoute.entries());
    this.logger.log(`\nðŸ“Š HOTEL FETCH RESULTS (ALL ENABLED PROVIDERS):`);
    hotelEntries.forEach(([routeId, hotels]) => {
      const tboCount = hotels.filter(h => h.provider === 'tbo').length;
      const hobseCount = hotels.filter(h => h.provider === 'hobse').length;
      const resavenueCount = hotels.filter(h => h.provider === 'resavenue').length;
      const axisroomsCount = hotels.filter(h => h.provider === 'axisrooms').length;
      const staahCount = hotels.filter(h => h.provider === 'staah').length;
      this.logger.log(`   Route ${routeId}: ${hotels.length} hotels (TBO: ${tboCount}, HOBSE: ${hobseCount}, ResAvenue: ${resavenueCount}, AxisRooms: ${axisroomsCount}, STAAH: ${staahCount})`);
      if (hotels.length > 0) {
     //   this.logger.log(`      - ${hotels.map(h => `${h.hotelName} (${h.provider})`).join(', ')}`);
      }
    });
    
    if (hotelEntries.every(([_, hotels]) => hotels.length === 0)) {
      this.logger.warn(`\nâŒ WARNING: ALL ROUTES RETURNED ZERO HOTELS!\n`);
    }
    
   // this.logger.log(`ðŸ¨ Hotels by Route: ${JSON.stringify(Object.fromEntries(hotelsByRoute))}`);

    // Step 4: Generate 4 price tier packages
    const packages = this.generatePricePackages(filteredHotelsByRoute, routes);

    // Step 5: Build response
    const response = await this.buildHotelDetailsResponse(
      quoteId,
      planId,
      packages,
      filteredHotelsByRoute,
      routes,
      noOfNights,
    );

    const duration = Date.now() - startTime;
    this.logger.log(`âœ… Generated ${packages.length} hotel packages`);
    this.logger.log(`â±ï¸  Total TBO Service Time: ${duration}ms\n`);

    // this.setCachedHotelDetails(quoteId, response);

    return hasCompatibilityFilters
      ? this.applyCompatibilityFilters(
          response,
          page,
          pageSize,
          groupType,
          itineraryRouteId,
        )
      : response;
  }

  // Backward-compatible alias used by older controllers/callers.
  clearHotelCacheForQuote(quoteId: string): void {
    this.clearCacheForQuote(quoteId);
  }

  private applyCompatibilityFilters(
    response: ItineraryHotelDetailsResponseDto,
    page?: number,
    pageSize?: number,
    groupType?: number,
    itineraryRouteId?: number,
  ): ItineraryHotelDetailsResponseDto {
    const normalizedGroupType = Number.isFinite(Number(groupType))
      ? Number(groupType)
      : undefined;
    const normalizedRouteId = Number.isFinite(Number(itineraryRouteId))
      ? Number(itineraryRouteId)
      : undefined;

    let filteredHotels = [...(response.hotels || [])];
    if (normalizedGroupType && normalizedGroupType >= 1 && normalizedGroupType <= 4) {
      filteredHotels = filteredHotels.filter((h) => Number(h.groupType) === normalizedGroupType);
    }
    if (normalizedRouteId && normalizedRouteId > 0) {
      filteredHotels = filteredHotels.filter((h) => Number(h.itineraryRouteId) === normalizedRouteId);
    }

    return {
      ...response,
      hotels: filteredHotels,
      pagination: undefined,
      routePagination: undefined,
    };
  }

  /**
   * Fetch available hotels from TBO for each route with OPTIMIZED city mapping
   * Uses batch city lookup and parallel processing instead of sequential queries
   */
  private async fetchHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
    childAges: number[] = [],
  ): Promise<Map<number, HotelSearchResult[] | null>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[] | null>();

    // ðŸ”¥ OPTIMIZATION 1: Batch load ALL cities upfront instead of querying per route
    const cityCodeMap = await this.batchMapDestinationsToCityCodes(routes);
    this.logger.log(`âœ… Pre-loaded ${Object.keys(cityCodeMap).length} city codes for all routes`);

    // Build stay blocks so TBO search is done once per destination-stay window,
    // not once per day/route.
    const stayBlocks = this.buildStayBlocks(routes, noOfNights);
    this.logger.log(`ðŸ§© Built ${stayBlocks.length} stay block(s) for consolidated TBO search`);

    // ðŸ”¥ OPTIMIZATION 2: Prepare all hotel search tasks for parallel execution
    const searchTasks: Promise<void>[] = [];

    for (const block of stayBlocks) {
      searchTasks.push(
        this.searchHotelsForStayBlock(
          block,
          cityCodeMap,
          guestNationality,
          roomCount,
          adultCount,
          childCount,
          childAges,
        )
          .then((hotels) => {
            block.routeIds.forEach((routeId) => hotelsByRoute.set(routeId, hotels || []));
          })
          .catch((error) => {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.logger.error(
              `âŒ HOTEL SEARCH ERROR for stay block ${block.destination} (${block.checkInDate} -> ${block.checkOutDate}): ${errorMsg}`,
            );
            block.routeIds.forEach((routeId) => hotelsByRoute.set(routeId, null)); // null = provider failure
          }),
      );
    }

    // ðŸ”¥ OPTIMIZATION 3: Execute all searches in parallel instead of sequentially
    this.logger.log(`â³ Starting ${searchTasks.length} parallel hotel searches...`);
    await Promise.all(searchTasks);
    this.logger.log(`âœ… All parallel searches completed`);

    return hotelsByRoute;
  }

  private buildStayBlocks(
    routes: any[],
    noOfNights: number,
  ): Array<{
    destination: string;
    checkInDate: string;
    checkOutDate: string;
    routeIds: number[];
  }> {
    const blocks: Array<{
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
    }> = [];

    const totalRoutes = routes.length;
    let currentBlock: {
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
      lastDate: Date;
    } | null = null;

    for (let routeIndex = 0; routeIndex < routes.length; routeIndex++) {
      const route = routes[routeIndex];
      const isLastRoute = routeIndex === totalRoutes - 1;
      if (isLastRoute && routeIndex >= noOfNights) {
        this.logger.log(`   â­ï¸  Skipping route ${routeIndex + 1} (last route - departure day, no hotel needed)`);
        continue;
      }

      const routeId = Number((route as any).itinerary_route_ID);
      const destination = String((route as any).next_visiting_location || '').trim();
      const routeDate = new Date((route as any).itinerary_route_date);
      const checkInDate = routeDate.toISOString().split('T')[0];
      const nextDay = new Date(routeDate.getTime() + ItineraryHotelDetailsTboService.ONE_DAY_MS);
      const checkOutDate = nextDay.toISOString().split('T')[0];

      if (!currentBlock) {
        currentBlock = {
          destination,
          checkInDate,
          checkOutDate,
          routeIds: [routeId],
          lastDate: routeDate,
        };
        continue;
      }

      const isSameDestination = destination === currentBlock.destination;
      const isConsecutiveDay =
        routeDate.getTime() - currentBlock.lastDate.getTime() === ItineraryHotelDetailsTboService.ONE_DAY_MS;

      if (isSameDestination && isConsecutiveDay) {
        currentBlock.checkOutDate = checkOutDate;
        currentBlock.routeIds.push(routeId);
        currentBlock.lastDate = routeDate;
      } else {
        blocks.push({
          destination: currentBlock.destination,
          checkInDate: currentBlock.checkInDate,
          checkOutDate: currentBlock.checkOutDate,
          routeIds: currentBlock.routeIds,
        });
        currentBlock = {
          destination,
          checkInDate,
          checkOutDate,
          routeIds: [routeId],
          lastDate: routeDate,
        };
      }
    }

    if (currentBlock) {
      blocks.push({
        destination: currentBlock.destination,
        checkInDate: currentBlock.checkInDate,
        checkOutDate: currentBlock.checkOutDate,
        routeIds: currentBlock.routeIds,
      });
    }

    return blocks;
  }

  /**
   * Batch load city codes for all destinations in one pass
   * Reduces database queries from NÃ—3 (N routes Ã— 3 attempts) to 1 query
   */
  private async batchMapDestinationsToCityCodes(routes: any[]): Promise<Record<string, string>> {
    const cityCodeMap: Record<string, string> = {};
    
    // Extract unique destinations from all routes
    const uniqueDestinations = [...new Set(routes.map(r => (r as any).next_visiting_location))];
    this.logger.log(`ðŸ“ Extracting city codes for ${uniqueDestinations.length} unique destinations`);

    if (uniqueDestinations.length === 0) return cityCodeMap;

    // âš¡ Load ALL cities from database in ONE query instead of per-route queries
    const allCities = await this.prisma.dvi_cities.findMany({
      select: { name: true, tbo_city_code: true },
    });
    this.logger.log(`âœ… Loaded ${allCities.length} cities from database in single query`);

    // Build a map for fast lookup
    const cityNameMap: Record<string, string> = {};
    const cityPrefixMap: Record<string, string> = {};
    
    allCities.forEach(city => {
      if (city.tbo_city_code) {
        cityNameMap[city.name.toLowerCase()] = city.tbo_city_code;
        const prefix = city.name.split(',')[0].trim().toUpperCase();
        cityPrefixMap[prefix] = city.tbo_city_code;
      }
    });

    // Map each destination to city code
    uniqueDestinations.forEach(destination => {
      if (!destination) return;

      // Try exact match (case-insensitive)
      let cityCode = cityNameMap[destination.toLowerCase()];
      
      if (!cityCode) {
        // Try partial match with first part
        const firstPart = destination.split(',')[0].trim();
        cityCode = cityNameMap[firstPart.toLowerCase()];
      }

      if (!cityCode) {
        // Try prefix match
        const prefix = destination.split(',')[0].trim().toUpperCase();
        cityCode = cityPrefixMap[prefix];
      }

      if (cityCode) {
        this.logger.log(`âœ… "${destination}" â†’ TBO Code: ${cityCode}`);
        cityCodeMap[destination] = cityCode;
      } else {
        this.logger.warn(`âŒ No city code found for: "${destination}"`);
      }
    });

    return cityCodeMap;
  }

  /**
     * Batch load HOBSE city codes for all destinations using hobse_city_code field.
     */
    private async batchMapDestinationsToHobseCityCodes(routes: any[]): Promise<Record<string, string>> {
      const cityCodeMap: Record<string, string> = {};
      const uniqueDestinations = [...new Set(routes.map(r => (r as any).next_visiting_location))] as string[];

      this.logger.log(`ðŸ“ Loading HOBSE city codes for ${uniqueDestinations.length} unique destinations`);
      if (uniqueDestinations.length === 0) return cityCodeMap;

      const allCities = await this.prisma.dvi_cities.findMany({
        select: { name: true, hobse_city_code: true } as any,
      });
      this.logger.log(`âœ… Loaded ${allCities.length} cities for HOBSE code lookup`);

      const cityNameMap: Record<string, string> = {};
      const cityPrefixMap: Record<string, string> = {};

      allCities.forEach((city: any) => {
        if (city.hobse_city_code) {
          cityNameMap[city.name.toLowerCase()] = String(city.hobse_city_code);
          const prefix = city.name.split(',')[0].trim().toLowerCase();
          cityPrefixMap[prefix] = String(city.hobse_city_code);
        }
      });

      uniqueDestinations.forEach(destination => {
        if (!destination) return;
        const lower = destination.toLowerCase();
        let code = cityNameMap[lower];

        if (!code) {
          const firstPart = destination.split(/[,\(\-]/)[0].trim().toLowerCase();
          code = cityNameMap[firstPart] || cityPrefixMap[firstPart];
        }

        if (code) {
          this.logger.log(`âœ… HOBSE "${destination}" -> code: ${code}`);
          cityCodeMap[destination] = code;
        } else {
          this.logger.warn(`âŒ No HOBSE city code found for: "${destination}"`);
        }
      });

      return cityCodeMap;
  }

  /**
   * Search hotels for a single route (used in parallel execution)
   */
  private async searchHotelsForStayBlock(
    block: {
      destination: string;
      checkInDate: string;
      checkOutDate: string;
      routeIds: number[];
    },
    cityCodeMap: Record<string, string>,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
    childAges: number[] = [],
  ): Promise<HotelSearchResult[]> {
    const destination = block.destination;

    this.logger.log(
      `ðŸ” Stay block (${block.routeIds.join(',')}): Searching hotels for "${destination}" (${block.checkInDate} -> ${block.checkOutDate})`,
    );

    // Get city code from pre-loaded map (no database query!)
    const cityCode = cityCodeMap[destination];

    // Fallback: if dvi_cities mapping is missing, use destination text directly.
    const effectiveCityCode = cityCode || destination;
    if (!cityCode) {
      this.logger.warn(
        `âš ï¸ Stay block (${block.routeIds.join(',')}): No mapped TBO city code for "${destination}". Falling back to destination text lookup.`,
      );
    }

    // Use pax counts from the plan; guarantee at least 1 adult so TBO validation passes
    if (adultCount <= 0) {
      this.logger.warn(
        `âš ï¸ Stay block (${block.routeIds.join(',')}): adultCount is ${adultCount} (not saved in plan?) - defaulting to 1`,
      );
    }
    const safeAdultCount = adultCount > 0 ? adultCount : 1;
    const safeChildCount = childCount >= 0 ? childCount : 0;
    const guestCount = safeAdultCount + safeChildCount;
    const safeRoomCount = Math.max(Number(roomCount || 1), 1);

    const tboOnlyFetch = this.isTboOnlyFetchEnabled();
    const searchProviders = tboOnlyFetch ? ['tbo'] : ['tbo', 'resavenue'];

    const searchCriteria = {
      cityCode: effectiveCityCode,
      checkInDate: block.checkInDate,
      checkOutDate: block.checkOutDate,
      roomCount: safeRoomCount,
      guestCount,
      adultCount: safeAdultCount,
      childCount: safeChildCount,
      childAges: childAges.length > 0 ? childAges : undefined,
      guestNationality,
      providers: searchProviders,
    };

    this.logger.log(
      `   ðŸ¨ Searching hotels with cityCode: ${effectiveCityCode}, checkIn: ${block.checkInDate}, checkOut: ${block.checkOutDate}`,
    );
    const hotels = await this.hotelSearchService.searchHotels(searchCriteria);
    this.logger.log(
      `   âœ… Found ${hotels ? hotels.length : 0} hotels for stay block (${block.routeIds.join(',')}) (TBO only at this stage)`,
    );
    
    if (hotels && hotels.length > 0) {
      this.logger.log(`   ðŸ“‹ TBO Hotels for stay block (${block.routeIds.join(',')}):`);
      hotels.forEach((h, idx) => {
      //  this.logger.log(`      ${idx + 1}. ${h.hotelName} (${h.provider}) - â‚¹${h.price}`);
      });
    } else {
      this.logger.log(`   âš ï¸  WARNING: TBO search returned ZERO hotels for stay block (${block.routeIds.join(',')})!`);
    }

    return hotels || [];
  }

  /**
   * Fetch HOBSE hotels for each route
   * Maps destinations to HOBSE city codes and calls HOBSE provider
   */
  private async fetchHobseHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    cityCodeMap: Record<string, string>,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    const totalRoutes = routes.length;

    this.logger.log(`\nðŸ¨ HOBSE HOTEL FETCH: Attempting to fetch HOBSE hotels for ${routes.length} routes`);

    try {
      for (let routeIndex = 0; routeIndex < routes.length; routeIndex++) {
        const route = routes[routeIndex];
        const routeId = (route as any).itinerary_route_ID;
        
        // Skip hotel generation for the last route (departure day) if routeIndex >= noOfNights
        const isLastRoute = routeIndex === totalRoutes - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   â­ï¸  Skipping HOBSE route ${routeIndex + 1} (last route - departure day)`);
          continue;
        }
        
        const destination = (route as any).next_visiting_location;
        // Get the HOBSE city code from the pre-built map
        const cityCode = cityCodeMap[destination];
        
        if (!cityCode) {
          this.logger.warn(`   âš ï¸  No HOBSE city code for destination "${destination}" - skipping HOBSE search`);
          hotelsByRoute.set(routeId, []);
          continue;
        }
        const routeDate = new Date((route as any).itinerary_route_date);
        const checkOutDate = new Date(routeDate);
        checkOutDate.setDate(checkOutDate.getDate() + 1);

        try {
          // Pass city code (number) instead of destination name (string)
          const hobseHotels = await this.hobseProvider.search({
            cityCode: cityCode,
            checkInDate: routeDate.toISOString().split('T')[0],
            checkOutDate: checkOutDate.toISOString().split('T')[0],
            roomCount: 1,
            guestCount: 2,
          });

          if (hobseHotels && hobseHotels.length > 0) {
            this.logger.log(`   âœ… HOBSE Route ${routeId}: Found ${hobseHotels.length} hotels in ${destination}`);
            hotelsByRoute.set(routeId, hobseHotels);
          } else {
            this.logger.log(`   â„¹ï¸  HOBSE Route ${routeId}: No hotels found in ${destination}`);
            hotelsByRoute.set(routeId, []);
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          this.logger.warn(`   âš ï¸  HOBSE Route ${routeId} search failed: ${errorMsg}`);
          hotelsByRoute.set(routeId, []);
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.logger.error(`âŒ HOBSE HOTEL FETCH FAILED: ${errorMsg}`);
    }

    return hotelsByRoute;
  }

  /**
   * Fetch ResAvenue hotels for each route
   * Searches for properties using destination city names
   */
  private async fetchResavenueHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    guestNationality: string,
    roomCount: number = 1,
    adultCount: number = 2,
    childCount: number = 0,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    const totalRoutes = routes.length;

    this.logger.log(`\nðŸ¨ RESAVENUE HOTEL FETCH: Attempting to fetch ResAvenue hotels for ${routes.length} routes`);

    try {
      const safeAdultCount = adultCount > 0 ? adultCount : 1;
      const safeChildCount = childCount >= 0 ? childCount : 0;
      const safeRoomCount = Math.max(Number(roomCount || 1), 1);
      const guestCount = safeAdultCount + safeChildCount;

      for (let routeIndex = 0; routeIndex < totalRoutes; routeIndex++) {
        const route = routes[routeIndex];
        const routeId = (route as any).itinerary_route_ID;
        
        // Skip hotel generation for the last route (departure day) if routeIndex >= noOfNights
        const isLastRoute = routeIndex === totalRoutes - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   â­ï¸  Skipping ResAvenue route ${routeIndex + 1} (last route - departure day)`);
          continue;
        }
        
        const destination = (route as any).next_visiting_location;
        const routeDate = new Date((route as any).itinerary_route_date);
        const checkOutDate = new Date(routeDate);
        checkOutDate.setDate(checkOutDate.getDate() + 1);

        try {
          // Search ResAvenue hotels using city name directly
          const resavenueHotels = await this.hotelSearchService.searchHotels({
            cityCode: destination, // ResAvenue provider accepts city names
            checkInDate: routeDate.toISOString().split('T')[0],
            checkOutDate: checkOutDate.toISOString().split('T')[0],
            roomCount: safeRoomCount,
            guestCount,
            adultCount: safeAdultCount,
            childCount: safeChildCount,
            guestNationality,
            providers: ['resavenue'], // Only ResAvenue
          });

          if (resavenueHotels && resavenueHotels.length > 0) {
            this.logger.log(`   âœ… ResAvenue Route ${routeId}: Found ${resavenueHotels.length} hotels in ${destination}`);
            hotelsByRoute.set(routeId, resavenueHotels);
          } else {
            this.logger.log(`   â„¹ï¸  ResAvenue Route ${routeId}: No hotels found in ${destination}`);
            hotelsByRoute.set(routeId, []);
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          this.logger.warn(`   âš ï¸  ResAvenue Route ${routeId} search failed: ${errorMsg}`);
          hotelsByRoute.set(routeId, []);
        }
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.logger.error(`âŒ RESAVENUE HOTEL FETCH FAILED: ${errorMsg}`);
    }

    return hotelsByRoute;
  }

  private normalizeCityToken(value: string): string {
    return String(value || '')
      .trim()
      .toLowerCase()
      .split(/[,(\-]/)[0]
      .trim();
  }

  private toIstDateOnly(value: unknown): Date {
    const raw = new Date(String(value || ''));
    if (Number.isNaN(raw.getTime())) {
      throw new Error(`Invalid route date: ${String(value || '')}`);
    }

    const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
    const istMoment = new Date(raw.getTime() + IST_OFFSET_MS);
    return new Date(Date.UTC(
      istMoment.getUTCFullYear(),
      istMoment.getUTCMonth(),
      istMoment.getUTCDate(),
      0,
      0,
      0,
      0,
    ));
  }

  private extractAxisroomsRate(occupancyRates: unknown): number {
    try {
      const data = occupancyRates as Record<string, unknown>;
      if (!data || typeof data !== 'object') return 0;

      const preferredKeys = ['SINGLE', 'DOUBLE', 'TRIPLE', 'QUAD', 'EXTRABED'];
      for (const key of preferredKeys) {
        const value = Number(data[key]);
        if (Number.isFinite(value) && value > 0) return value;
      }

      for (const value of Object.values(data)) {
        const num = Number(value);
        if (Number.isFinite(num) && num > 0) return num;
      }
    } catch {
      return 0;
    }

    return 0;
  }

  private extractStaahRate(occupancyRates: unknown): number {
    const asPositive = (value: unknown): number => {
      const num = Number(value);
      return Number.isFinite(num) && num > 0 ? num : 0;
    };
    const scan = (value: unknown): number => {
      if (typeof value === 'string') {
        const raw = value.trim();
        if (!raw) return 0;
        try {
          return scan(JSON.parse(raw));
        } catch {
          return 0;
        }
      }
      if (Array.isArray(value)) {
        for (const item of value) {
          const n = asPositive(item);
          if (n > 0) return n;
          const deep = scan(item);
          if (deep > 0) return deep;
        }
        return 0;
      }
      if (!value || typeof value !== 'object') return 0;
      const obj = value as Record<string, unknown>;
      const preferred = ['amountAfterTax', 'amountBeforeTax', 'single', 'double', 'base', 'rate', 'price'];
      for (const key of preferred) {
        const n = asPositive(obj[key]);
        if (n > 0) return n;
      }
      for (const nested of Object.values(obj)) {
        const direct = asPositive(nested);
        if (direct > 0) return direct;
        const deep = scan(nested);
        if (deep > 0) return deep;
      }
      return 0;
    };
    return scan(occupancyRates);
  }

  /**
   * Load saved meal plan codes for each route in the itinerary
   * Maps route IDs to their configured meal plan codes (e.g., "AP", "CP", "EP", "MAP")
   */
  private async loadSavedMealPlansPerRoute(
    planId: number,
    routes: any[],
  ): Promise<Map<number, string>> {
    const mealPlansByRoute = new Map<number, string>();
    
    try {
      // Fetch saved hotel details with rateplan_id to determine meal plan
      const savedHotels = await (this.prisma as any).dvi_itinerary_plan_hotel_details.findMany({
        where: {
          itinerary_plan_id: planId,
          deleted: 0,
        },
        select: {
          itinerary_route_id: true,
          group_type: true,
        },
      });

      // For now, just track that this route has a saved hotel (we'll filter by first rate plan found)
      for (const hotel of savedHotels as any[]) {
        const routeId = Number((hotel as any).itinerary_route_id || 0);
        if (routeId > 0) {
          mealPlansByRoute.set(routeId, 'SAVED'); // Mark as saved (not a fresh search)
        }
      }

      if (mealPlansByRoute.size > 0) {
        this.logger.log(`âœ… Found ${mealPlansByRoute.size} routes with saved hotels`);
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      this.logger.warn(`âš ï¸ Failed to load saved hotel indicators: ${errorMsg}`);
    }

    return mealPlansByRoute;
  }

  private async fetchAxisroomsHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    savedMealPlansByRoute?: Map<number, string>,
    preferredMealPlanCode?: string | null,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    const totalRoutes = routes.length;

    this.logger.log(`\nðŸ¨ AXISROOMS HOTEL FETCH: Attempting to fetch AxisRooms hotels for ${routes.length} routes`);

    const axisroomsHotels = await this.prisma.dvi_hotel.findMany({
      where: {
        axisrooms_enabled: 1,
        status: 1,
        OR: [{ deleted: false }, { deleted: null }],
      } as any,
      select: {
        hotel_id: true,
        hotel_name: true,
        hotel_city: true,
        hotel_address: true,
        hotel_category: true,
        hotel_cancel_policy: true,
      },
    });

    if (!axisroomsHotels.length) {
      this.logger.log('   â„¹ï¸  No axisrooms-enabled hotels found in local DB');
      return hotelsByRoute;
    }

    // hotel_city may be stored as a numeric city ID string (e.g. "1979") or a plain name.
    // Build a map from city id -> city name so both cases resolve correctly.
    const numericCityIds = Array.from(
      new Set(
        axisroomsHotels
          .map((h: any) => Number((h as any).hotel_city))
          .filter((id) => Number.isFinite(id) && id > 0),
      ),
    );
    const cityIdNameMap = new Map<number, string>();
    if (numericCityIds.length > 0) {
      const cityRows = await this.prisma.dvi_cities.findMany({
        where: { id: { in: numericCityIds } },
        select: { id: true, name: true },
      });
      for (const c of cityRows as any[]) {
        cityIdNameMap.set(Number((c as any).id), String((c as any).name || ''));
      }
    }

    for (let routeIndex = 0; routeIndex < totalRoutes; routeIndex++) {
      const route = routes[routeIndex];
      const routeId = Number((route as any).itinerary_route_ID);
      const isLastRoute = routeIndex === totalRoutes - 1;
      if (isLastRoute && routeIndex >= noOfNights) {
        this.logger.log(`   â­ï¸  Skipping AxisRooms route ${routeIndex + 1} (last route - departure day)`);
        continue;
      }

      const destinationRaw = String((route as any).next_visiting_location || '');
      const routeCityToken = this.normalizeCityToken(destinationRaw);
      const dateOnly = this.toIstDateOnly((route as any).itinerary_route_date);
      const dateStamp = dateOnly.toISOString().split('T')[0].replace(/-/g, '');

      const cityHotels = axisroomsHotels.filter((h: any) => {
        const rawCity = String((h as any).hotel_city || '');
        // Resolve: if it looks like a numeric ID, look up the actual city name
        const numId = Number(rawCity);
        const resolvedCity = (Number.isFinite(numId) && numId > 0 && cityIdNameMap.has(numId))
          ? cityIdNameMap.get(numId)!
          : rawCity;
        const hotelCityToken = this.normalizeCityToken(resolvedCity);
        return !!hotelCityToken && hotelCityToken === routeCityToken;
      });

      if (!cityHotels.length) {
        hotelsByRoute.set(routeId, []);
        this.logger.log(`   â„¹ï¸  AxisRooms Route ${routeId}: No axisrooms hotels mapped for city ${destinationRaw}`);
        continue;
      }

      const hotelIds = cityHotels.map((h: any) => Number((h as any).hotel_id)).filter((id) => Number.isFinite(id) && id > 0);

      const amenityRows = await this.prisma.dvi_hotel_amenities.findMany({
        where: {
          hotel_id: { in: hotelIds },
          deleted: 0,
          status: 1,
        } as any,
        select: {
          hotel_id: true,
          amenities_title: true,
        },
      });
      const amenitiesByHotel = new Map<number, string[]>();
      for (const amenity of amenityRows as any[]) {
        const hid = Number((amenity as any).hotel_id || 0);
        if (!hid) continue;
        const title = String((amenity as any).amenities_title || '').trim();
        if (!title) continue;
        if (!amenitiesByHotel.has(hid)) {
          amenitiesByHotel.set(hid, []);
        }
        amenitiesByHotel.get(hid)!.push(title);
      }
      const availRows = await this.prisma.dvi_hotel_room_availability.findMany({
        where: {
          hotel_id: { in: hotelIds },
          start_date: { lte: dateOnly },
          end_date: { gte: dateOnly },
          free: { gt: 0 },
        },
        select: {
          hotel_id: true,
          room_id: true,
          free: true,
        },
      });

      if (!availRows.length) {
        hotelsByRoute.set(routeId, []);
        this.logger.log(`   â„¹ï¸  AxisRooms Route ${routeId}: No available inventory for ${destinationRaw} on ${dateOnly.toISOString().split('T')[0]}`);
        continue;
      }

      const roomIds = Array.from(new Set(availRows.map((r) => Number((r as any).room_id)).filter((id) => Number.isFinite(id) && id > 0)));

      // AxisRooms gate: keep only rooms that have an active AxisRooms-mapped rate plan
      // (axisrooms_room_id NOT NULL = mapped from inbound AxisRooms room/rateplan setup).
      // Occupancy rows may be sourced from AxisRooms or manual admin updates; we do not hard-filter source here.
      const activeRatePlanRows = await this.prisma.dvi_hotel_room_rate_plan.findMany({
        where: {
          hotel_id: { in: hotelIds },
          room_id: { in: roomIds },
          axisrooms_room_id: { not: null },
          deleted: 0,
          status: 1,
        } as any,
        select: {
          hotel_id: true,
          room_id: true,
          rateplan_id: true,
          rateplan_name: true,
          meal_plan_description: true,
        },
      });

      const ratePlanMetaByHotelRoom = new Map<string, { rateConditions: string[]; inclusions: string[] }>();
      for (const rp of activeRatePlanRows as any[]) {
        const key = `${Number((rp as any).hotel_id)}|${Number((rp as any).room_id)}`;
        if (!ratePlanMetaByHotelRoom.has(key)) {
          ratePlanMetaByHotelRoom.set(key, { rateConditions: [], inclusions: [] });
        }
        const meta = ratePlanMetaByHotelRoom.get(key)!;
        const rateCondition = String((rp as any).rateplan_name || '').trim();
        const inclusion = String((rp as any).meal_plan_description || '').trim();
        if (rateCondition) {
          meta.rateConditions.push(rateCondition);
        }
        if (inclusion) {
          meta.inclusions.push(inclusion);
        }
      }
              const mealPlanByRatePlan = new Map<string, string>();
              for (const rp of activeRatePlanRows as any[]) {
                const rateplanId = String((rp as any).rateplan_id || '').trim();
                const mealPlanDesc = String((rp as any).meal_plan_description || '').trim();
                if (rateplanId && mealPlanDesc && !mealPlanByRatePlan.has(rateplanId)) {
                  mealPlanByRatePlan.set(rateplanId, mealPlanDesc);
                }
              }
              const validRatePlanKeySet = new Set<string>(
        activeRatePlanRows.map(
          (rp: any) => `${Number((rp as any).hotel_id)}|${Number((rp as any).room_id)}|${String((rp as any).rateplan_id || '')}`,
        ),
      );

      const occupancyRowsRaw = await this.prisma.dvi_hotel_occupancy_rate.findMany({
        where: {
          hotel_id: { in: hotelIds },
          room_id: { in: roomIds },
          start_date: { lte: dateOnly },
          end_date: { gte: dateOnly },
        },
        select: {
          hotel_id: true,
          room_id: true,
          rateplan_id: true,
          occupancy_rates: true,
        },
      });

      const occupancyRows = occupancyRowsRaw.filter((row: any) => {
        const key = `${Number((row as any).hotel_id)}|${Number((row as any).room_id)}|${String((row as any).rateplan_id || '')}`;
        return validRatePlanKeySet.has(key);
      });

      const roomMeta = await this.prisma.dvi_hotel_rooms.findMany({
        where: {
          room_ID: { in: roomIds as any },
          deleted: 0,
        } as any,
        select: {
          room_ID: true,
          room_title: true,
        },
      });
      const roomTitleMap = new Map<number, string>(
        roomMeta.map((r: any) => [Number((r as any).room_ID), String((r as any).room_title || 'Room')]),
      );

      const availableRoomByHotel = new Map<number, Set<number>>();
      for (const row of availRows as any[]) {
        const hid = Number((row as any).hotel_id);
        const rid = Number((row as any).room_id);
        if (!availableRoomByHotel.has(hid)) {
          availableRoomByHotel.set(hid, new Set<number>());
        }
        availableRoomByHotel.get(hid)!.add(rid);
      }

      const axisroomsRouteHotels: HotelSearchResult[] = [];

      for (const hotel of cityHotels as any[]) {
        const hid = Number((hotel as any).hotel_id);
        const roomSet = availableRoomByHotel.get(hid);
        if (!roomSet || roomSet.size === 0) {
          continue;
        }

        // Group occupancy rows by rateplan_id and extract rate from each plan
        const ratesByPlan = new Map<string, { rate: number; roomId: number }>();

        for (const occ of occupancyRows as any[]) {
          if (Number((occ as any).hotel_id) !== hid) continue;
          const rid = Number((occ as any).room_id);
          if (!roomSet.has(rid)) continue;

          const rateplanId = String((occ as any).rateplan_id || '').trim();
          if (!rateplanId) continue;

          // Only extract rate if we haven't found one for this rate plan yet
          if (!ratesByPlan.has(rateplanId)) {
            const extractedRate = this.extractAxisroomsRate((occ as any).occupancy_rates);
            if (extractedRate > 0) {
              ratesByPlan.set(rateplanId, { rate: extractedRate, roomId: rid });
            }
          }
        }

        if (ratesByPlan.size === 0) {
          this.logger.warn(
            `   ??  AxisRooms Route ${routeId}: Hotel ${hid} - No valid rates found in any occupancy row for this hotel/room (checked ${occupancyRows.filter((o: any) => Number((o as any).hotel_id) === hid).length} rows)`
          );
          continue; // No valid rates found for any meal plan
        }

        const preferredCode = String(preferredMealPlanCode || '').trim().toUpperCase();
        const preferredDef = preferredCode
          ? HOTEL_RATE_PLAN_BY_CODE.get(preferredCode as any)
          : undefined;
        const preferredRatePlanCandidates = [
          String(preferredDef?.defaultRateplanId || '').trim(),
          String(preferredDef?.externalRateplanId || '').trim(),
        ].filter((x) => !!x);

        let selectedRateplanId = '';
        let selectedRate = Number.POSITIVE_INFINITY;
        let selectedRoomId = 0;

        for (const candidate of preferredRatePlanCandidates) {
          const hit = ratesByPlan.get(candidate);
          if (hit) {
            selectedRateplanId = candidate;
            selectedRate = Number(hit.rate);
            selectedRoomId = Number(hit.roomId);
            break;
          }
        }

        // Fallback: if preferred meal plan isn't present for this hotel, pick the lowest available rate plan.
        if (!selectedRateplanId) {
          for (const [rpid, hit] of ratesByPlan.entries()) {
            const rateVal = Number(hit.rate);
            if (Number.isFinite(rateVal) && rateVal > 0 && rateVal < selectedRate) {
              selectedRateplanId = rpid;
              selectedRate = rateVal;
              selectedRoomId = Number(hit.roomId);
            }
          }
        }

        if (!selectedRateplanId || !Number.isFinite(selectedRate) || selectedRate <= 0 || !selectedRoomId) {
          continue;
        }

        const rate = selectedRate;

        const roomName = roomTitleMap.get(selectedRoomId) || 'Room';
        const hotelAmenities = Array.from(new Set(amenitiesByHotel.get(hid) || []));
        const rateMeta = ratePlanMetaByHotelRoom.get(`${hid}|${selectedRoomId}`) || {

          rateConditions: [],
          inclusions: [],
        };
        const rateConditions = Array.from(new Set(rateMeta.rateConditions));
        const inclusions = Array.from(new Set(rateMeta.inclusions));
        const cancelPolicyText = String((hotel as any).hotel_cancel_policy || '').trim();

        const selectedMealPlan = mealPlanByRatePlan.get(selectedRateplanId) || '-';

        axisroomsRouteHotels.push({
          provider: 'axisrooms',
          hotelCode: String(hid),
          hotelName: String((hotel as any).hotel_name || `Hotel ${hid}`),
          cityCode: String((hotel as any).hotel_city || destinationRaw),
          address: String((hotel as any).hotel_address || ''),
          rating: Number((hotel as any).hotel_category || 0),
          facilities: hotelAmenities,
          amenities: hotelAmenities,
          inclusions,
          rateConditions,
          cancellationPolicy: cancelPolicyText ? [cancelPolicyText] : [],
          images: [],
          price: Number(rate),
          currency: 'INR',
          roomTypes: [
            {
              roomCode: String(selectedRoomId),
              roomName,
              bedType: '',
              capacity: 0,
              price: Number(rate),
              cancellationPolicy: cancelPolicyText,
            },
          ],
          roomType: roomName,
          mealPlan: selectedMealPlan,
          searchReference: `AX-${hid}-${dateStamp}`,
          expiresAt: new Date(Date.now() + 15 * 60 * 1000),
        });
      }

      hotelsByRoute.set(routeId, axisroomsRouteHotels);
      const droppedByRatePlanGate = Math.max(occupancyRowsRaw.length - occupancyRows.length, 0);
      this.logger.log(
        `   âœ… AxisRooms Route ${routeId}: Found ${axisroomsRouteHotels.length} hotels in ${destinationRaw} (ratePlan-gated, droppedRows=${droppedByRatePlanGate})`,
      );
    }

    return hotelsByRoute;
  }

  private async fetchStaahHotelsForRoutes(
    routes: any[],
    noOfNights: number,
    savedMealPlansByRoute?: Map<number, string>,
    preferredMealPlanCode?: string | null,
  ): Promise<Map<number, HotelSearchResult[]>> {
    const hotelsByRoute = new Map<number, HotelSearchResult[]>();
    let staahHotels: any[] = [];
    try {
      staahHotels = await this.prisma.dvi_hotel.findMany({
        where: {
          staah_enabled: 1,
          status: 1,
          deleted: { not: true },
        },
        select: { hotel_id: true, hotel_name: true, hotel_city: true, hotel_address: true, hotel_category: true, hotel_cancel_policy: true, staah_property_id: true },
      });
    } catch (error) {
      this.logger.error(`[STAAH] Failed loading STAAH-enabled hotels: ${error instanceof Error ? error.message : String(error)}`);
      return hotelsByRoute;
    }
    if (!staahHotels.length) return hotelsByRoute;
    const cityIds = Array.from(new Set(staahHotels.map((h: any) => Number((h as any).hotel_city)).filter((x) => Number.isFinite(x) && x > 0)));
    const cityRows = cityIds.length ? await this.prisma.dvi_cities.findMany({ where: { id: { in: cityIds } }, select: { id: true, name: true } }) : [];
    const cityMap = new Map<number, string>(cityRows.map((c: any) => [Number(c.id), String(c.name || '')]));

    for (let routeIndex = 0; routeIndex < routes.length; routeIndex++) {
      try {
        const route = routes[routeIndex];
        const routeId = Number((route as any).itinerary_route_ID);
        const isLastRoute = routeIndex === routes.length - 1;
        if (isLastRoute && routeIndex >= noOfNights) continue;
        const destinationRaw = String((route as any).next_visiting_location || '');
        const routeCityToken = this.normalizeCityToken(destinationRaw);
        const dateOnly = this.toIstDateOnly((route as any).itinerary_route_date);
        const dateStamp = dateOnly.toISOString().split('T')[0].replace(/-/g, '');
        const cityHotels = staahHotels.filter((h: any) => {
          const raw = String((h as any).hotel_city || '');
          const nid = Number(raw);
          const resolved = Number.isFinite(nid) && nid > 0 && cityMap.has(nid) ? cityMap.get(nid)! : raw;
          const hotelCityToken = this.normalizeCityToken(resolved);
          const cityMatch = !!hotelCityToken && hotelCityToken === routeCityToken;
          if (Number((h as any).hotel_id) === 44674) {
            this.logger.log(
              `[STAAH DEBUG] hotel=44674 routeId=${routeId} next_visiting_location="${destinationRaw}" ` +
              `routeCityToken="${routeCityToken}" resolvedHotelCity="${resolved}" hotelCityToken="${hotelCityToken}" cityMatch=${cityMatch}`,
            );
          }
          return cityMatch;
        });
        if (!cityHotels.length) {
          this.logger.log(`[STAAH DEBUG] routeId=${routeId} matched STAAH city hotels=0`);
          hotelsByRoute.set(routeId, []);
          continue;
        }
        const propertyIds = cityHotels.map((h: any) => String((h as any).staah_property_id || '').trim()).filter(Boolean);
        const [inventoryRows, ratePlanRows] = await Promise.all([
          (this.prisma as any).staah_inventory.findMany({ where: { staah_property_id: { in: propertyIds }, start_date: { lte: dateOnly }, end_date: { gte: dateOnly }, free: { gt: 0 } } }),
          (this.prisma as any).staah_rateplan.findMany({ where: { staah_property_id: { in: propertyIds } } }),
        ]);
        if (!inventoryRows.length || !ratePlanRows.length) {
          const targetHotel = cityHotels.find((h: any) => Number((h as any).hotel_id) === 44674);
          if (targetHotel) {
            this.logger.warn(
              `[STAAH DEBUG] hotel=44674 routeId=${routeId} propertyId=${String((targetHotel as any).staah_property_id || '')} ` +
              `inventoryCount=${inventoryRows.length} rateplanCount=${ratePlanRows.length} reason=${!inventoryRows.length ? 'no inventory' : 'no rateplan'}`,
            );
          }
          hotelsByRoute.set(routeId, []);
          continue;
        }
        const roomIds = Array.from(new Set(inventoryRows.map((r: any) => String(r.room_id || '').trim()).filter(Boolean)));
        const ratePlanIds = Array.from(new Set(ratePlanRows.map((r: any) => String(r.rateplan_id || '').trim()).filter(Boolean)));
        const [rateRows, restrictionRows, roomRows] = await Promise.all([
          (this.prisma as any).staah_rate.findMany({ where: { staah_property_id: { in: propertyIds }, room_id: { in: roomIds }, rateplan_id: { in: ratePlanIds }, start_date: { lte: dateOnly }, end_date: { gte: dateOnly } } }),
          (this.prisma as any).staah_restriction.findMany({ where: { staah_property_id: { in: propertyIds }, room_id: { in: roomIds }, rateplan_id: { in: ratePlanIds }, start_date: { lte: dateOnly }, end_date: { gte: dateOnly } } }),
          this.prisma.dvi_hotel_rooms.findMany({ where: { deleted: 0 } as any, select: { room_ID: true, room_ref_code: true, room_title: true } as any }),
        ]);
        const stopsellSet = new Set<string>();
        for (const row of restrictionRows as any[]) {
          const restrictionType = String((row as any).type || (row as any).name || (row as any).restriction_type || '').toLowerCase();
          if (!(restrictionType.includes('stopsell') || restrictionType.includes('stop_sell'))) continue;
          if (!['1', 'true', 'yes', 'y'].includes(String((row as any).value || '').toLowerCase())) continue;
          stopsellSet.add(`${row.staah_property_id}|${row.room_id}|${row.rateplan_id}`);
        }
        const roomTitleMap = new Map<string, string>();
        for (const room of roomRows as any[]) {
          roomTitleMap.set(String((room as any).room_ref_code || '').trim(), String((room as any).room_title || '').trim());
          roomTitleMap.set(String((room as any).room_ID || '').trim(), String((room as any).room_title || '').trim());
        }
        const results: HotelSearchResult[] = [];
        for (const hotel of cityHotels as any[]) {
          const propertyId = String((hotel as any).staah_property_id || '').trim();
          const propertyInventoryRows = (inventoryRows as any[]).filter((r) => String((r as any).staah_property_id || '') === propertyId);
          const propertyRatePlanRows = (ratePlanRows as any[]).filter((r) => String((r as any).staah_property_id || '') === propertyId);
          const rows = (rateRows as any[]).filter((r) => String((r as any).staah_property_id || '') === propertyId);
          const propertyRestrictionRows = (restrictionRows as any[]).filter((r) => String((r as any).staah_property_id || '') === propertyId);
          let selected: any = null;
          let selectedReason = 'no valid rate';
          let best = Number.POSITIVE_INFINITY;
          let blockedByStopSell = false;
          for (const rate of rows) {
            const rateKey = `${rate.staah_property_id}|${rate.room_id}|${rate.rateplan_id}`;
            if (stopsellSet.has(rateKey)) {
              blockedByStopSell = true;
              selectedReason = `stopsell blocked rateplan ${String((rate as any).rateplan_id || '')}`;
              continue;
            }
            const price = this.extractStaahRate((rate as any).occupancy_rates);
            if (price <= 0) {
              selectedReason = `no positive price for rateplan ${String((rate as any).rateplan_id || '')}`;
              continue;
            }
            const rp = (ratePlanRows as any[]).find((x) => String(x.staah_property_id) === String(rate.staah_property_id) && String(x.rateplan_id) === String(rate.rateplan_id));
            const preferredCode = String(preferredMealPlanCode || '').trim().toUpperCase();
            const preferredDef = preferredCode ? HOTEL_RATE_PLAN_BY_CODE.get(preferredCode as any) : undefined;
            const preferredIds = [String(preferredDef?.defaultRateplanId || ''), String(preferredDef?.externalRateplanId || '')].filter(Boolean);
            const mealText = `${String((rp as any)?.rateplan_name || '')} ${String((rp as any)?.meal_plan_description || '')}`.toLowerCase();
            const preferHit = preferredCode && (preferredIds.includes(String((rate as any).rateplan_id || '')) || mealText.includes(preferredCode.toLowerCase()));
            if (preferHit || price < best) {
              if (!selected || price < best) {
                selected = { rate, rp, price };
                best = price;
                selectedReason = preferHit ? `matched preferred meal plan ${preferredCode}` : 'selected cheapest valid rate';
              }
            }
          }
          if (Number((hotel as any).hotel_id) === 44674) {
            this.logger.log(
              `[STAAH DEBUG] hotel=44674 routeId=${routeId} propertyId=${propertyId} inventoryCount=${propertyInventoryRows.length} ` +
              `rateplanCount=${propertyRatePlanRows.length} rateCount=${rows.length} restrictionCount=${propertyRestrictionRows.length} ` +
              `stopsellBlocked=${blockedByStopSell}`,
            );
          }
          if (!selected) {
            if (Number((hotel as any).hotel_id) === 44674) {
              this.logger.warn(
                `[STAAH DEBUG] hotel=44674 routeId=${routeId} propertyId=${propertyId} reasonNotSelected=${selectedReason}`,
              );
            }
            continue;
          }
          const roomId = String((selected.rate as any).room_id || '');
          const roomName = roomTitleMap.get(roomId) || `Room ${roomId}`;
          const cancellation = String((hotel as any).hotel_cancel_policy || '').trim();
          const mealPlan = String((selected.rp as any)?.meal_plan_description || (selected.rp as any)?.rateplan_name || '-').trim() || '-';
          const currency = String((selected.rp as any)?.currency || 'INR').trim() || 'INR';
          if (Number((hotel as any).hotel_id) === 44674) {
            this.logger.log(
              `[STAAH DEBUG] hotel=44674 routeId=${routeId} propertyId=${propertyId} selectedRate=${Number((selected as any).price)} ` +
              `selectedRoom=${roomId} selectedRateplan=${String((selected.rate as any).rateplan_id || '')} selectedMealPlan="${mealPlan}"`,
            );
          }
          results.push({
          provider: 'staah',
          hotelCode: String((hotel as any).hotel_id),
          hotelName: String((hotel as any).hotel_name || ''),
          cityCode: String((hotel as any).hotel_city || destinationRaw),
          address: String((hotel as any).hotel_address || ''),
          rating: Number((hotel as any).hotel_category || 0),
          facilities: [],
          amenities: [],
          inclusions: [],
          rateConditions: [],
          cancellationPolicy: cancellation ? [cancellation] : [],
          images: [],
          price: Number((selected as any).price),
          currency,
          roomTypes: [{ roomCode: roomId, roomName, bedType: '', capacity: 0, price: Number((selected as any).price), cancellationPolicy: cancellation }],
          roomType: roomName,
          mealPlan,
          searchReference: `STAAH-${propertyId}-${roomId}-${String((selected.rate as any).rateplan_id)}-${dateStamp}`,
          expiresAt: new Date(Date.now() + 15 * 60 * 1000),
          });
        }
        hotelsByRoute.set(routeId, results);
      } catch (error) {
        const routeId = Number((routes[routeIndex] as any)?.itinerary_route_ID || 0);
        this.logger.error(`[STAAH] Route ${routeId} failed: ${error instanceof Error ? error.message : String(error)}`);
        if (routeId > 0) hotelsByRoute.set(routeId, []);
      }
    }
    return hotelsByRoute;
  }


  private generatePricePackages(
    hotelsByRoute: Map<number, HotelSearchResult[]>,
    routes: any[],
  ): Array<{ groupType: number; label: string; hotels: Array<HotelSearchResult & { routeId: number }> }> {
    const packages: Array<{
      groupType: number;
      label: string;
      hotels: Array<HotelSearchResult & { routeId: number }>;
    }> = [];

    const labels = [
      'Budget Hotels',
      'Mid-Range Hotels',
      'Premium Hotels',
      'Luxury Hotels',
    ];

    // Debug: Log all available hotels
    this.logger.log(`\n   ðŸ“Š PRICE TIER GENERATION DEBUG (PER-DESTINATION):`);
    this.logger.log(`   Total routes: ${routes.length}`);
    hotelsByRoute.forEach((hotels, routeId) => {
      const prices = hotels.map(h => h.price).join(', ');
      this.logger.log(`   Route ${routeId}: ${hotels.length} hotels (Prices: ${prices})`);
    });

    // NEW LOGIC: Assign hotels to groups PER DESTINATION (per route)
    // Rule: If 1 hotel -> put in all 4 groups
    //       If 2+ hotels -> distribute in ascending price order across groups
    
    // First pass: Determine groupType for each hotel based on its destination
    const hotelGroupAssignments = new Map<string, number>(); // key: "routeId-hotelCode" -> groupType
    
    for (const route of routes) {
      const routeId = (route as any).itinerary_route_ID;
      const availableHotels = hotelsByRoute.get(routeId);

      if (availableHotels === null) {
        this.logger.warn(`      ðŸš¨ Provider/system failure for route ${routeId} â€” skipping placeholder row. See previous logs for error.`);
        continue;
      }
      if (!Array.isArray(availableHotels) || availableHotels.length === 0) {
        this.logger.warn(`      âš ï¸  No hotels available for route ${routeId}`);
        continue;
      }

      // Sort hotels by price (ascending) for this destination
      const sortedHotels = [...availableHotels].sort((a, b) => a.price - b.price);

      if (sortedHotels.length === 1) {
        // Single hotel: assign to ALL 4 groups
        const hotel = sortedHotels[0];
        for (let groupType = 1; groupType <= 4; groupType++) {
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          hotelGroupAssignments.set(`${key}:${groupType}`, groupType);
        }
        this.logger.debug(`   Route ${routeId}: 1 hotel - "${hotel.hotelName}" (â‚¹${hotel.price}) assigned to ALL groups`);
      } else {
        // Multiple hotels: distribute across groups by price order
        const numHotels = sortedHotels.length;
        const groupsNeeded = Math.min(numHotels, 4);
        
        sortedHotels.forEach((hotel, index) => {
          // Map hotels to groups in ascending price order
          let groupType = 1;
          if (numHotels <= 4) {
            // Fewer hotels than groups: distribute evenly
            groupType = Math.min(index + 1, 4);
          } else {
            // More hotels than groups: distribute proportionally
            groupType = Math.floor((index / numHotels) * 4) + 1;
            groupType = Math.min(groupType, 4);
          }
          
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          hotelGroupAssignments.set(`${key}:${groupType}`, groupType);
        });
        
        this.logger.debug(`   Route ${routeId}: ${numHotels} hotels - Distributed across groups by price order`);
        sortedHotels.forEach((h, i) => {
          const key = `${routeId}-${h.hotelCode || h.hotelName}`;
          let groupType = 1;
          if (numHotels <= 4) {
            groupType = Math.min(i + 1, 4);
          } else {
            groupType = Math.floor((i / numHotels) * 4) + 1;
            groupType = Math.min(groupType, 4);
          }
       //   this.logger.debug(`      "${h.hotelName}" (â‚¹${h.price}) -> Group ${groupType}`);
        });
      }
    }

    // Second pass: Build packages from the assignments
    for (let tier = 0; tier < 4; tier++) {
      const groupType = tier + 1;
      const tieredHotels: Array<HotelSearchResult & { routeId: number }> = [];

      for (const route of routes) {
        const routeId = (route as any).itinerary_route_ID;
        const availableHotels = hotelsByRoute.get(routeId);

        if (availableHotels === null) {
          this.logger.warn(`   ðŸš¨ Provider/system failure for route ${routeId} â€” not inserting placeholder row. See previous logs for error.`);
          continue;
        }
        if (!Array.isArray(availableHotels) || availableHotels.length === 0) {
          this.logger.debug(`   Tier ${groupType}, Route ${routeId}: No hotels available`);
          // CREATE PLACEHOLDER FOR NO HOTELS - price 0
          const placeholderHotel: any = {
            hotelCode: '0',
            hotelName: 'No Hotels Available',
            roomType: '-',
            mealPlan: '-',
            price: 0,
            rating: 0,
            routeId: routeId
          };
          tieredHotels.push(placeholderHotel);
          continue;
        }

        let foundForGroup = false;

        // Get hotels that belong to this tier for this route
        for (const hotel of availableHotels) {
          const key = `${routeId}-${hotel.hotelCode || hotel.hotelName}`;
          const assignedGroupType = hotelGroupAssignments.get(`${key}:${groupType}`);
          
          if (assignedGroupType === groupType) {
            const hotelWithRoute = { ...hotel, routeId } as HotelSearchResult & { routeId: number };
            tieredHotels.push(hotelWithRoute);
            foundForGroup = true;
          }
        }

        // Overlap fallback: if this route has hotels but none mapped to current tier,
        // pick deterministic fallback by sorted price index so every tier has data.
        if (!foundForGroup && availableHotels.length > 0) {
          const sortedHotels = [...availableHotels].sort((a, b) => (a.price || 0) - (b.price || 0));
          const fallbackIndex = Math.min(groupType - 1, sortedHotels.length - 1);
          const fallbackHotel = sortedHotels[fallbackIndex];
          if (fallbackHotel) {
            const fallbackWithRoute = {
              ...fallbackHotel,
              routeId,
              __fallbackAssigned: true,
            } as HotelSearchResult & { routeId: number };
            tieredHotels.push(fallbackWithRoute);
            this.logger.debug(
              `   Tier ${groupType}, Route ${routeId}: overlap fallback -> ${fallbackHotel.hotelName}`,
            );
          }
        }
      }

      // Add package with ALL matching hotels for this tier
      if (tieredHotels.length > 0) {
        const totalPrice = tieredHotels.reduce((sum, h) => sum + h.price, 0);
        packages.push({
          groupType: groupType,
          label: labels[tier],
          hotels: tieredHotels,
        });
        this.logger.log(`   âœ… Group ${groupType} (${labels[tier]}): ${tieredHotels.length} hotels total, â‚¹${totalPrice} combined`);
      } else {
        this.logger.log(`   âš ï¸  Group ${groupType} (${labels[tier]}): No hotels found for any route`);
      }
    }

    this.logger.log(`ðŸ“¦ Generated ${packages.length} price tier packages\n`);
    return packages;
  }

  /**
   * Build the response DTO
   */
  private async buildHotelDetailsResponse(
    quoteId: string,
    planId: number,
    packages: Array<{ groupType: number; label: string; hotels: Array<HotelSearchResult & { routeId: number }> }>,
    hotelsByRoute: Map<number, HotelSearchResult[]>,
    routes: any[],
    noOfNights: number,
  ): Promise<ItineraryHotelDetailsResponseDto> {
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      select: { hotel_rates_visibility: true },
    });

    const hotelRatesVisible =
      Number((plan as any)?.hotel_rates_visibility || 0) === 1 ||
      (plan as any)?.hotel_rates_visibility === true;

    // Build hotel tabs (one per package with total cost)
    const hotelTabs: ItineraryHotelTabDto[] = packages.map((pkg) => {
      const totalAmount = pkg.hotels.reduce((sum, h) => sum + h.price, 0);
      return {
        groupType: pkg.groupType,
        label: pkg.label,
        totalAmount,
      };
    });

    // Fetch all hotel details from database to get IDs and voucher status
    const hotelDetailsInDb = await this.prisma.dvi_itinerary_plan_hotel_details.findMany({
      where: { itinerary_plan_id: planId, deleted: 0 },
      select: {
        itinerary_plan_hotel_details_ID: true,
        itinerary_route_id: true,
        hotel_id: true,
        group_type: true,
      },
    });

    // Fetch voucher cancellation statuses
    const hotelDetailsIds = hotelDetailsInDb.map(h => h.itinerary_plan_hotel_details_ID);
    const voucherStatuses = hotelDetailsIds.length > 0
      ? await this.prisma.dvi_confirmed_itinerary_plan_hotel_voucher_details.findMany({
          where: {
            itinerary_plan_id: planId,
            itinerary_plan_hotel_details_ID: { in: hotelDetailsIds },
            deleted: 0,
          },
          select: {
            itinerary_plan_hotel_details_ID: true,
            hotel_voucher_cancellation_status: true,
          },
        })
      : [];

    // Create maps for quick lookup
    const detailsMap = new Map(
      hotelDetailsInDb.map(d => [
        `${d.itinerary_route_id}-${d.hotel_id}-${d.group_type}`,
        d.itinerary_plan_hotel_details_ID
      ])
    );
    
    const voucherStatusMap = new Map(
      voucherStatuses.map(v => [
        v.itinerary_plan_hotel_details_ID,
        v.hotel_voucher_cancellation_status === 1
      ])
    );

    // Preload route destination coordinates and hotel coordinates for distance calculation.
    const routeLocationIds = Array.from(
      new Set(
        routes
          .map((r: any) => Number((r as any).location_id || 0))
          .filter((id: number) => id > 0),
      ),
    );

    const storedLocations = routeLocationIds.length
      ? await this.prisma.dvi_stored_locations.findMany({
          where: { location_ID: { in: routeLocationIds }, deleted: 0 },
          select: {
            location_ID: true,
            destination_location_lattitude: true,
            destination_location_longitude: true,
          },
        })
      : [];

    const routeDestinationCoordsByLocationId = new Map<number, { lat: number; lon: number }>();
    for (const loc of storedLocations as any[]) {
      const lat = Number((loc as any).destination_location_lattitude ?? 0);
      const lon = Number((loc as any).destination_location_longitude ?? 0);
      if (Number.isFinite(lat) && Number.isFinite(lon) && lat !== 0 && lon !== 0) {
        routeDestinationCoordsByLocationId.set(Number((loc as any).location_ID), { lat, lon });
      }
    }

    const providerCodeSet = new Set<string>();
    for (const pkg of packages) {
      for (const h of pkg.hotels) {
        const provider = String((h as any).provider || 'tbo').trim().toLowerCase();
        const code = String((h as any).hotelCode || '').trim();
        if (!code) continue;
        providerCodeSet.add(`${provider}|${code}`);
      }
    }

    const tboCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('tbo|'))
      .map((k) => k.slice(4));
    const resavenueCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('resavenue|'))
      .map((k) => k.slice('resavenue|'.length));
    const hobseCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('hobse|'))
      .map((k) => k.slice(6));
    const axisroomsCodes = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('axisrooms|'))
      .map((k) => k.slice('axisrooms|'.length));
    const axisroomsHotelIds = axisroomsCodes
      .map((code) => Number(code))
      .filter((id) => Number.isFinite(id) && id > 0);
    const staahHotelIds = Array.from(providerCodeSet)
      .filter((k) => k.startsWith('staah|'))
      .map((k) => Number(k.slice('staah|'.length)))
      .filter((id) => Number.isFinite(id) && id > 0);

    const hotelMasters = providerCodeSet.size
      ? await this.prisma.dvi_hotel.findMany({
          where: {
            OR: [
              ...(tboCodes.length
                ? [{ tbo_hotel_code: { in: tboCodes } }]
                : []),
              ...(resavenueCodes.length
                ? [{ resavenue_hotel_code: { in: resavenueCodes } }]
                : []),
              ...(hobseCodes.length
                ? [{ hotel_code: { in: hobseCodes } }]
                : []),
              ...(axisroomsHotelIds.length
                ? [{ hotel_id: { in: axisroomsHotelIds } }]
                : []),
              ...(staahHotelIds.length
                ? [{ hotel_id: { in: staahHotelIds } }]
                : []),
            ],
          },
          select: {
            hotel_id: true,
            tbo_hotel_code: true,
            resavenue_hotel_code: true,
            hotel_code: true,
            hotel_latitude: true,
            hotel_longitude: true,
          },
        })
      : [];

    const hotelCoordsByProviderCode = new Map<string, { lat: number; lon: number }>();
    for (const hm of hotelMasters as any[]) {
      const lat = Number((hm as any).hotel_latitude ?? 0);
      const lon = Number((hm as any).hotel_longitude ?? 0);
      if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat === 0 || lon === 0) {
        continue;
      }

      const tboCode = String((hm as any).tbo_hotel_code || '').trim();
      const resavenueCode = String((hm as any).resavenue_hotel_code || '').trim();
      const hobseCode = String((hm as any).hotel_code || '').trim();
      const hotelId = Number((hm as any).hotel_id || 0);

      if (tboCode) hotelCoordsByProviderCode.set(`tbo|${tboCode}`, { lat, lon });
      if (resavenueCode) hotelCoordsByProviderCode.set(`resavenue|${resavenueCode}`, { lat, lon });
      if (hobseCode) hotelCoordsByProviderCode.set(`hobse|${hobseCode}`, { lat, lon });
      if (hotelId > 0) hotelCoordsByProviderCode.set(`axisrooms|${hotelId}`, { lat, lon });
      if (hotelId > 0) hotelCoordsByProviderCode.set(`staah|${hotelId}`, { lat, lon });
    }

    // Fallback: TBO static master has wider code coverage than dvi_hotel in many environments.
    if (tboCodes.length > 0) {
      const tboMasterRows = await this.prisma.tbo_hotel_master.findMany({
        where: { tbo_hotel_code: { in: tboCodes } },
        select: {
          tbo_hotel_code: true,
          hotel_latitude: true,
          hotel_longitude: true,
        },
      });

      for (const row of tboMasterRows as any[]) {
        const code = String((row as any).tbo_hotel_code || '').trim();
        const lat = Number((row as any).hotel_latitude ?? 0);
        const lon = Number((row as any).hotel_longitude ?? 0);
        if (!code || !Number.isFinite(lat) || !Number.isFinite(lon) || lat === 0 || lon === 0) {
          continue;
        }

        const key = `tbo|${code}`;
        if (!hotelCoordsByProviderCode.has(key)) {
          hotelCoordsByProviderCode.set(key, { lat, lon });
        }
      }
    }

    // STAAH confirmed booking override map (latest row per route)
    const confirmedStaahRows = await (this.prisma as any).staah_hotel_booking_confirmation.findMany({
      where: {
        itinerary_plan_ID: planId,
        status: 1,
        deleted: 0,
      },
      orderBy: { staah_hotel_booking_confirmation_ID: 'desc' },
    });
    const confirmedStaahByRouteId = new Map<number, any>();
    for (const row of confirmedStaahRows as any[]) {
      const routeId = Number((row as any).itinerary_route_ID || 0);
      if (routeId > 0 && !confirmedStaahByRouteId.has(routeId)) {
        confirmedStaahByRouteId.set(routeId, row);
      }
    }

    // Build hotel rows (detail rows for each package)
    const hotelRows: ItineraryHotelRowDto[] = [];

    for (const pkg of packages) {
      for (const hotel of pkg.hotels) {
        // Find the route using the routeId attached to the hotel
        const route = routes.find((r: any) => r.itinerary_route_ID === hotel.routeId);
        if (!route) {
          this.logger.warn(`âš ï¸  Route ${hotel.routeId} not found for hotel ${hotel.hotelName}`);
          continue;
        }
        
        // Skip departure day (last route when routeIndex >= noOfNights)
        const routeIndex = routes.indexOf(route);
        const isLastRoute = routeIndex === routes.length - 1;
        if (isLastRoute && routeIndex >= noOfNights) {
          this.logger.log(`   â­ï¸  Skipping route ${hotel.routeId} from response (departure day)`);
          continue;
        }
        
        // Use next_visiting_location (where you're staying) for destination display
        const destination = (route as any).next_visiting_location || (route as any).location_name || '';
        
        // Use actual hotel name from TBO API response
        const displayHotelName = hotel.hotelName;
        
        // Handle both TBO (numeric) and HOBSE (UUID string) hotel codes
        const hotelId = isNaN(parseInt(hotel.hotelCode)) ? 0 : parseInt(hotel.hotelCode);
        const routeId = (route as any).itinerary_route_ID;
        const dateLabel = new Date((route as any).itinerary_route_date).toISOString().split('T')[0];
        
        // Lookup hotel details ID and voucher status (only for TBO numeric IDs)
        const lookupKey = hotelId > 0 ? `${routeId}-${hotelId}-${pkg.groupType}` : '';
        const hotelDetailsId = lookupKey ? detailsMap.get(lookupKey) : undefined;
        const voucherCancelled = hotelDetailsId ? (voucherStatusMap.get(hotelDetailsId) || false) : false;

        let hotelDistance: string | null = null;
        const routeLocationId = Number((route as any).location_id || 0);
        const routeCoords = routeDestinationCoordsByLocationId.get(routeLocationId);
        const providerCodeKey = `${String(hotel.provider || 'tbo').trim().toLowerCase()}|${String(hotel.hotelCode || '').trim()}`;
        const hotelCoords = hotelCoordsByProviderCode.get(providerCodeKey);
        if (routeCoords && hotelCoords) {
          try {
            const distanceKm = haversineKm(
              routeCoords.lat,
              routeCoords.lon,
              hotelCoords.lat,
              hotelCoords.lon,
            );
            if (Number.isFinite(distanceKm) && distanceKm > 0) {
              hotelDistance = `${distanceKm.toFixed(2)} KM`;
            }
          } catch {
            hotelDistance = null;
          }
        }

        hotelRows.push({
          groupType: pkg.groupType,
          itineraryRouteId: routeId,
          day: `Day ${routeIndex + 1} | ${dateLabel}`,
          destination: destination,
          hotelId: hotelId,
          hotelName: displayHotelName,
          category: hotel.rating ? parseInt(String(hotel.rating)) : 0,
          roomType: hotel.roomType || '',
          mealPlan: hotel.mealPlan || '',
          totalHotelCost: Math.round(hotel.price),
          totalHotelTaxAmount: 0,
          searchReference: hotel.searchReference,
          bookingCode:
            (hotel.provider || 'tbo').toLowerCase() === 'tbo'
              ? hotel.searchReference || hotel.roomTypes?.[0]?.roomCode || undefined
              : hotel.hotelCode,
          provider: hotel.provider || 'tbo',
          voucherCancelled: voucherCancelled,
          itineraryPlanHotelDetailsId: hotelDetailsId || 0,
          date: dateLabel,
          hotelDistance,
          inclusions: hotel.inclusions && hotel.inclusions.length > 0 ? hotel.inclusions : (hotel.facilities && hotel.facilities.length > 0 ? hotel.facilities : undefined),
          amenities: hotel.amenities && hotel.amenities.length > 0 ? hotel.amenities : undefined,
          facilities: hotel.facilities && hotel.facilities.length > 0 ? hotel.facilities : undefined,
          rateConditions: hotel.rateConditions && hotel.rateConditions.length > 0 ? hotel.rateConditions : undefined,
          cancellationPolicy: Array.isArray((hotel as any).cancellationPolicy)
            ? (hotel as any).cancellationPolicy
            : (typeof (hotel as any).cancellationPolicy === 'string' && String((hotel as any).cancellationPolicy).trim()
              ? [String((hotel as any).cancellationPolicy).trim()]
              : undefined),
          supplementSummary: hotel.supplementSummary,
        });

        // Log HOBSE hotel codes for debugging
        if (hotel.provider === 'HOBSE') {
          this.logger.debug(`âœ… HOBSE Hotel Response: hotelCode="${hotel.hotelCode}", provider="${hotel.provider}"`);
        }
      }
    }

    // Override only matching routes with confirmed STAAH booking rows
    if (confirmedStaahByRouteId.size > 0) {
      for (let i = 0; i < hotelRows.length; i++) {
        const row: any = hotelRows[i];
        const routeId = Number(row?.itineraryRouteId || 0);
        const confirmedRow: any = confirmedStaahByRouteId.get(routeId);
        if (!confirmedRow) continue;

        const apiResponse: any = (confirmedRow as any).api_response || {};
        const reservation: any =
          apiResponse?.confirm?.request?.reservations?.reservation?.[0] || {};
        const reservationRoom: any = reservation?.room?.[0] || {};
        const reservationPrice: any = reservationRoom?.price?.[0] || {};

        const hotelCodeNum = Number((confirmedRow as any).staah_hotel_code || 0);
        const safeCheckIn = (confirmedRow as any).check_in_date
          ? new Date((confirmedRow as any).check_in_date).toISOString().split('T')[0]
          : row.date;

        hotelRows[i] = {
          ...row,
          provider: 'staah',
          itineraryRouteId: routeId,
          hotelId: Number.isFinite(hotelCodeNum) ? hotelCodeNum : 0,
          hotelName: String(reservation?.propertyname || 'STAAH Hotel'),
          roomType: String(reservationRoom?.room_name || ''),
          mealPlan: String(reservationPrice?.rate_name || ''),
          totalHotelCost: Number((confirmedRow as any).net_amount || 0),
          totalHotelTaxAmount: Number(reservation?.totaltax || 0),
          bookingCode: String((confirmedRow as any).booking_code || ''),
          searchReference: String((confirmedRow as any).staah_booking_reference || ''),
          voucherCancelled: false,
          itineraryPlanHotelDetailsId: 0,
          date: safeCheckIn,
          checkInDate: (confirmedRow as any).check_in_date || undefined,
          checkOutDate: (confirmedRow as any).check_out_date || undefined,
          numberOfRooms: Number((confirmedRow as any).number_of_rooms || 0),
          guestNationality: String((confirmedRow as any).guest_nationality || ''),
          totalGuests: Number((confirmedRow as any).total_guests || 0),
          isConfirmedBooking: true,
          voucherAvailable: true,
        } as any;

        this.logger.log(
          `[HOTEL_DETAILS_CONFIRMED_STAAH_OVERRIDE] quoteId=${quoteId} planId=${planId} routeId=${routeId} staahHotelCode=${String((confirmedRow as any).staah_hotel_code || '')} bookingReference=${String((confirmedRow as any).staah_booking_reference || '')}`,
        );
      }
    }

    const supplierHotelRows = hotelRows.filter(
      (row) => row.hotelId > 0 && row.hotelName !== 'No Hotels Available',
    );
    const placeholderRows = hotelRows.filter(
      (row) => row.hotelName === 'No Hotels Available',
    );

    const searchableRouteIds = routes
      .filter((route, index) => {
        const isLastRoute = index === routes.length - 1;
        return !(isLastRoute && index >= noOfNights);
      })
      .map((route: any) => Number(route.itinerary_route_ID));

    const totalSearchRoutes = searchableRouteIds.length;
    const emptySearchRoutes = searchableRouteIds.filter((routeId) => {
      const routeHotels = hotelsByRoute.get(routeId) || [];
      return routeHotels.length === 0;
    }).length;

    const hasSupplierHotels = supplierHotelRows.length > 0;
    const isPlaceholderOnly = !hasSupplierHotels && placeholderRows.length > 0;
    const availabilityMessage = isPlaceholderOnly
      ? 'Supplier search completed but no available rooms were returned for the selected city/date criteria.'
      : hasSupplierHotels
        ? 'Live supplier hotels are available for the current itinerary selection.'
        : 'No hotel data available yet. Try refreshing search or adjusting criteria.';

    return {
      quoteId,
      planId,
      hotelRatesVisible,
      hotelTabs,
      hotels: hotelRows,
      totalRoomCount: hotelRows.length,
      hotelAvailability: {
        hasSupplierHotels,
        supplierHotelCount: supplierHotelRows.length,
        placeholderRowCount: placeholderRows.length,
        totalSearchRoutes,
        emptySearchRoutes,
        isPlaceholderOnly,
        message: availabilityMessage,
      },
    };
  }

  /**
   * Get fresh hotel room details from TBO API (no stale data)
   * Fetches real-time data and returns in room details format
   * Uses caching by route to minimize TBO API calls within a session
   * @param quoteId - The quote ID to fetch hotel rooms for
   * @param filterRouteId - Optional: Filter results to only this route ID
   */
  async getHotelRoomDetailsFromTbo(
    quoteId: string,
    filterRouteId?: number,
  ): Promise<ItineraryHotelRoomDetailsResponseDto> {
    const startTime = Date.now();
    this.logger.log(`\nðŸ“¡ FRESH ROOM DETAILS FROM TBO: Fetching live data for quote: ${quoteId}`);
    if (filterRouteId) {
      this.logger.log(`ðŸ” Filtering to route ID: ${filterRouteId}`);
    }

    // âœ… CHECK CACHE FIRST (per-route caching)
    const cachedResult = this.getCachedRoomDetails(quoteId, filterRouteId);
    if (cachedResult) {
      return cachedResult;
    }

    // Step 1: Get itinerary plan
    const plan = await this.prisma.dvi_itinerary_plan_details.findFirst({
      where: { itinerary_quote_ID: quoteId, deleted: 0 },
    });

    if (!plan) {
      this.logger.warn(`âš ï¸  Quote ID not found: ${quoteId}`);
      throw new NotFoundException('Itinerary not found');
    }

    const planId = plan.itinerary_plan_ID;
    this.logger.log(`âœ… Found plan ID: ${planId}`);

    // Step 2: Get itinerary routes (days and destinations)
    const routes = await this.prisma.dvi_itinerary_route_details.findMany({
      where: { itinerary_plan_ID: planId, deleted: 0 },
      orderBy: { itinerary_route_date: 'asc' },
    });

    if (routes.length === 0) {
      this.logger.warn(`âš ï¸  No routes found for plan ${planId}`);
      throw new BadRequestException('Itinerary has no routes');
    }

    const noOfNights = Number((plan as any).no_of_nights || 0);
    this.logger.log(`ðŸŒ™ Plan has ${noOfNights} nights`);

    const planRoomCount2 = Math.max(Number((plan as any).preferred_room_count || 1), 1);
    const planAdultCount2 = Number((plan as any).total_adult || 0);
    const planChildCount2 = Number((plan as any).total_children || 0);

    let planChildAges2: number[] = [];
    if (planChildCount2 > 0) {
      const childTravellers2 = await this.prisma.dvi_itinerary_traveller_details.findMany({
        where: { itinerary_plan_ID: planId, traveller_type: 2, deleted: 0 },
        orderBy: { traveller_details_ID: 'asc' },
      });
      planChildAges2 = childTravellers2
        .map((t) => Math.trunc(Number((t as any).traveller_age)))
        .filter((age) => Number.isFinite(age) && age >= 0 && age <= 11);
    }

    // Step 3: Fetch FRESH hotels from TBO
    // OPTIMIZATION: If filterRouteId provided, only fetch hotels for that specific route
    let routesToProcess = routes;
    if (filterRouteId) {
      routesToProcess = routes.filter(r => (r as any).itinerary_route_ID === filterRouteId);
      if (routesToProcess.length === 0) {
        this.logger.warn(`âš ï¸  Route ID ${filterRouteId} not found`);
        throw new BadRequestException(`Route ID ${filterRouteId} not found in this itinerary`);
      }
      this.logger.log(`âœ… Optimized: Fetching hotels for 1 route only (filtered)`);
    }

    const guestNationality = await this.resolveGuestNationality(plan);
    const hotelsByRoute = await this.fetchHotelsForRoutes(
      routesToProcess,
      noOfNights,
      guestNationality,
      planRoomCount2,
      planAdultCount2,
      planChildCount2,
      planChildAges2,
    );

    // Merge non-TBO providers (HOBSE, ResAvenue, AxisRooms) â€” same logic as getHotelDetails
    const tboOnlyFetch = this.isTboOnlyFetchEnabled();
    if (!tboOnlyFetch) {
      if (this.isHobseSearchEnabled()) {
        const hobseCityCodeMap = await this.batchMapDestinationsToHobseCityCodes(routesToProcess);
        const hobseHotelsByRoute = await this.fetchHobseHotelsForRoutes(routesToProcess, noOfNights, hobseCityCodeMap);
        hobseHotelsByRoute.forEach((hobseHotels, routeId) => {
          const existing = hotelsByRoute.get(routeId) || [];
          hotelsByRoute.set(routeId, [...existing, ...hobseHotels]);
        });
      } else {
        this.logger.warn('âš ï¸ HOBSE_SEARCH_ENABLED=0: skipping HOBSE hotel search results');
      }

      // ResAvenue
      const resavenueHotelsByRoute = await this.fetchResavenueHotelsForRoutes(
        routesToProcess,
        noOfNights,
        guestNationality,
        planRoomCount2,
        planAdultCount2,
        planChildCount2,
      );
      resavenueHotelsByRoute.forEach((resavenueHotels, routeId) => {
        const existing = hotelsByRoute.get(routeId) || [];
        const hotelStrs = existing.map(h => `${h.hotelCode}|${h.provider}`);
        const newHotels = resavenueHotels.filter(h => !hotelStrs.includes(`${h.hotelCode}|${h.provider}`));
        hotelsByRoute.set(routeId, [...existing, ...newHotels]);
      });

      // AxisRooms
      const axisroomsHotelsByRoute = await this.fetchAxisroomsHotelsForRoutes(routesToProcess, noOfNights);
      axisroomsHotelsByRoute.forEach((axisroomsHotels, routeId) => {
        const existing = hotelsByRoute.get(routeId) || [];
        const hotelStrs = existing.map(h => `${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`);
        const newHotels = axisroomsHotels.filter(h => !hotelStrs.includes(`${String(h.hotelCode)}|${String(h.provider).toLowerCase()}`));
        hotelsByRoute.set(routeId, [...existing, ...newHotels]);
      });
    }

    // Step 4: Transform fresh data into room details format
    const roomDetailsList: ItineraryHotelRoomDto[] = [];
    let roomDetailsId = 1;

    // Build route-scoped room candidates with group coverage fallback.
    // PHP behavior allows overlap fallback when a recommendation bucket would be empty.
    const routeHotelRows: Array<{ routeId: number; hotel: any }> = [];

    hotelsByRoute.forEach((hotelsForRoute, routeId) => {
      // FILTER: Only process this route if filterRouteId is not provided OR if it matches
      if (filterRouteId && routeId !== filterRouteId) {
        this.logger.debug(`ðŸ” Skipping route ${routeId} (filter: ${filterRouteId})`);
        return;
      }

      const allPrices = hotelsForRoute.map((h: HotelSearchResult) => h.price || 0);
      const sortedHotels = [...hotelsForRoute].sort((a, b) => (a.price || 0) - (b.price || 0));

      const byGroup = new Map<number, any[]>();

      hotelsForRoute.forEach((hotel: HotelSearchResult) => {
        const hotelPrice = hotel.price || 0;
        const groupType = this.getGroupTypeFromPrice(hotelPrice, allPrices);
        if (!byGroup.has(groupType)) byGroup.set(groupType, []);
        byGroup.get(groupType)!.push({ ...hotel, groupType, __fallbackAssigned: false });
      });

      // Ensure all 4 groups are represented when a route has at least one hotel.
      for (let groupType = 1; groupType <= 4; groupType++) {
        const groupHotels = byGroup.get(groupType) ?? [];
        if (groupHotels.length === 0 && sortedHotels.length > 0) {
          const fallbackIndex = Math.min(groupType - 1, sortedHotels.length - 1);
          const fallbackHotel = sortedHotels[fallbackIndex];
          if (fallbackHotel) {
            byGroup.set(groupType, [
              {
                ...fallbackHotel,
                groupType,
                __fallbackAssigned: true,
              },
            ]);
          }
        }
      }

      for (let groupType = 1; groupType <= 4; groupType++) {
        const groupHotels = byGroup.get(groupType) ?? [];
        groupHotels.forEach((hotel) => routeHotelRows.push({ routeId, hotel }));
      }
    });

    // Build room entries from fresh TBO data
    routeHotelRows.forEach(({ routeId, hotel }) => {
      const route = routes.find(r => (r as any).itinerary_route_ID === routeId);
      if (!route) return;

        // âœ… FIXED: Use actual room type from TBO, not groupType
        const firstRoomType = hotel.roomTypes?.[0];
        const actualRoomTypeId = firstRoomType?.roomTypeId || 1;
        // For non-TBO providers use hotel.roomType which matches hotel_details; for TBO use roomTypes[0].roomName
        const actualRoomTypeName = String(hotel.provider || 'tbo').toLowerCase() !== 'tbo'
          ? (hotel.roomType || firstRoomType?.roomName || 'Standard Room')
          : (firstRoomType?.roomName || hotel.roomType || 'Standard Room');

        roomDetailsList.push({
          itineraryPlanId: planId,
          itineraryRouteId: routeId,
          itineraryPlanHotelRoomDetailsId: roomDetailsId++,
          hotelId: parseInt(hotel.hotelCode) || 0,
          hotelName: hotel.hotelName || 'Hotel',
          hotelCategory: this.getCategoryFromRating(hotel.category || hotel.rating),
          groupType: hotel.groupType || 1, // âœ… ADD: Include groupType (tier: 1-4)
          roomTypeId: actualRoomTypeId, // âœ… FIXED: Use actual TBO room type ID
          roomTypeName: actualRoomTypeName, // âœ… FIXED: Use actual TBO room type name
          roomId: parseInt(hotel.hotelCode) || 0,
          provider: String(hotel.provider || 'tbo').toLowerCase(),
          availableRoomTypes: (hotel.roomTypes || []).map((rt, idx) => ({
            roomTypeId: rt.roomTypeId || idx + 1,
            roomTypeTitle: rt.roomName,
            bookingCode: rt.roomCode,
          })),
          bookingCode: String(hotel.provider || 'tbo').toLowerCase() === 'tbo'
            ? (firstRoomType?.roomCode || hotel.searchReference || undefined)
            : (hotel.hotelCode || hotel.searchReference || undefined),
          pricePerNight: Number(hotel.price || 0),
          numberOfNights: noOfNights,
          totalPrice: Number(hotel.price || 0) * noOfNights,
          currency: hotel.currency || 'INR',
          mealPlan: hotel.mealPlan || 'Not Specified',
          facilities: hotel.facilities || [],
          amenities: hotel.amenities || [],
          inclusions: hotel.inclusions || [],
          rateConditions: (hotel.rateConditions || []) as string[],
          cancellationPolicy: Array.isArray((hotel as any).cancellationPolicy)
            ? (hotel as any).cancellationPolicy
            : (typeof (hotel as any).cancellationPolicy === 'string' && String((hotel as any).cancellationPolicy).trim()
              ? [String((hotel as any).cancellationPolicy).trim()]
              : (firstRoomType?.cancellationPolicy ? [String(firstRoomType.cancellationPolicy)] : [])),
        } as any);
    });

    const duration = Date.now() - startTime;
    this.logger.log(`âœ… FRESH ROOM DETAILS GENERATED`);
    this.logger.log(`ðŸ“Š Room Entries: ${roomDetailsList.length}`);
    if (filterRouteId) {
      this.logger.log(`ðŸ” Filter Applied: Route ID ${filterRouteId}`);
    } else {
      this.logger.log(`ðŸ“… All Routes Included`);
    }
    this.logger.log(`â±ï¸  Duration: ${duration}ms\n`);

    const result = {
      quoteId: (plan as any).itinerary_quote_ID ?? '',
      planId,
      rooms: roomDetailsList,
    };

    // âœ… CACHE THE RESULT for future requests
    this.setCachedRoomDetails(quoteId, result, filterRouteId);

    return result;
  }

  /**
   * Determine group type (price tier) based on hotel price relative to all hotels
   * Distributes hotels across 4 tiers: Budget (1), Mid-Range (2), Premium (3), Luxury (4)
   */
  private getGroupTypeFromPrice(
    hotelPrice: number,
    allPrices: number[]
  ): number {
    if (allPrices.length === 0) return 1;
    if (allPrices.length === 1) return 1;

    // Sort prices to find quartiles
    const sortedPrices = [...allPrices].sort((a, b) => a - b);
    
    // Calculate quartile boundaries
    const q1 = sortedPrices[Math.floor(sortedPrices.length * 0.25)];
    const q2 = sortedPrices[Math.floor(sortedPrices.length * 0.50)];
    const q3 = sortedPrices[Math.floor(sortedPrices.length * 0.75)];

    // Assign tier based on price quartile
    if (hotelPrice <= q1) return 1; // Budget (bottom 25%)
    if (hotelPrice <= q2) return 2; // Mid-Range (25-50%)
    if (hotelPrice <= q3) return 3; // Premium (50-75%)
    return 4; // Luxury (top 25%)
  }

  /**
   * Convert rating/category string to numeric category (1-4)
   */
  private getCategoryFromRating(ratingOrCategory: string | number | undefined): number {
    if (!ratingOrCategory) return 2; // Default to Mid-Range
    
    const val = typeof ratingOrCategory === 'string' 
      ? parseInt(ratingOrCategory)
      : ratingOrCategory;
    
    if (val >= 5 || val === 4) return 4; // Luxury (5-star)
    if (val === 3) return 3; // Premium (3-star equivalent)
    if (val === 2) return 2; // Mid-Range (2-star)
    return 1; // Budget
  }

  /**
   * Generate cache key for hotel room details
   * Format: "quoteId" or "quoteId:routeId" if filtered
   */
  private getCacheKey(quoteId: string, routeId?: number): string {
    if (routeId) {
      return `${quoteId}:${routeId}`;
    }
    return quoteId;
  }

  /**
   * Get cached hotel room details if available
   */
  private getCachedRoomDetails(quoteId: string, routeId?: number): ItineraryHotelRoomDetailsResponseDto | null {
    const cacheKey = this.getCacheKey(quoteId, routeId);
    const cached = this.hotelRoomDetailsCache.get(cacheKey);
    
    if (cached) {
      if (this.isCacheExpired(cached.timestamp, ItineraryHotelDetailsTboService.HOTEL_ROOM_DETAILS_CACHE_TTL_MS)) {
        this.hotelRoomDetailsCache.delete(cacheKey);
        this.logger.debug(`ðŸ’¾ [CACHE EXPIRED] Removed stale room cache for ${cacheKey}`);
        return null;
      }
      this.logger.log(`ðŸ’¾ [CACHE HIT] Using cached data for ${cacheKey}`);
      return cached.data;
    }
    
    return null;
  }

  /**
   * Store hotel room details in cache
   */
  private setCachedRoomDetails(
    quoteId: string,
    data: ItineraryHotelRoomDetailsResponseDto,
    routeId?: number,
  ): void {
    const cacheKey = this.getCacheKey(quoteId, routeId);
    this.evictOldestIfNeeded(this.hotelRoomDetailsCache);
    this.hotelRoomDetailsCache.set(cacheKey, {
      data,
      timestamp: Date.now(),
    });
    this.logger.log(`ðŸ’¾ [CACHE SET] Cached data for ${cacheKey}`);
  }

  private getCachedHotelDetails(quoteId: string): ItineraryHotelDetailsResponseDto | null {
    const cached = this.hotelDetailsCache.get(quoteId);
    if (!cached) {
      return null;
    }

    if (this.isCacheExpired(cached.timestamp, ItineraryHotelDetailsTboService.HOTEL_DETAILS_CACHE_TTL_MS)) {
      this.hotelDetailsCache.delete(quoteId);
      this.logger.debug(`ðŸ’¾ [CACHE EXPIRED] Removed stale hotel details cache for ${quoteId}`);
      return null;
    }

    this.logger.log(`ðŸ’¾ [CACHE HIT] Hotel details from cache for ${quoteId}`);
    return cached.data;
  }

  private setCachedHotelDetails(
    quoteId: string,
    data: ItineraryHotelDetailsResponseDto,
  ): void {
    this.evictOldestIfNeeded(this.hotelDetailsCache);
    this.hotelDetailsCache.set(quoteId, {
      data,
      timestamp: Date.now(),
    });
    this.logger.log(`ðŸ’¾ [CACHE SET] Hotel details cached for ${quoteId}`);
  }

  private isCacheExpired(timestamp: number, ttlMs: number): boolean {
    return Date.now() - timestamp > ttlMs;
  }

  private evictOldestIfNeeded<T extends { timestamp: number }>(cache: Map<string, T>): void {
    if (cache.size < ItineraryHotelDetailsTboService.MAX_CACHE_ENTRIES) {
      return;
    }

    let oldestKey: string | null = null;
    let oldestTs = Number.MAX_SAFE_INTEGER;

    cache.forEach((value, key) => {
      if (value.timestamp < oldestTs) {
        oldestTs = value.timestamp;
        oldestKey = key;
      }
    });

    if (oldestKey) {
      cache.delete(oldestKey);
    }
  }

  /**
   * Clear cache for a specific quote (called on refresh/update)
   * Clears both general cache (quoteId) and route-specific caches (quoteId:routeId)
   */
  clearCacheForQuote(quoteId: string): void {
    const keysToDelete: string[] = [];

    this.hotelDetailsCache.delete(quoteId);
    
    for (const key of this.hotelRoomDetailsCache.keys()) {
      if (key.startsWith(`${quoteId}:`)) { // Matches "quoteId:routeId"
        keysToDelete.push(key);
      }
    }
    
    // Also delete the base key
    keysToDelete.push(quoteId);
    
    for (const key of keysToDelete) {
      this.hotelRoomDetailsCache.delete(key);
      this.logger.log(`ðŸ—‘ï¸  [CACHE CLEARED] Removed cache for ${key}`);
    }
  }

  /**
   * Get current cache size and stats (for debugging)
   */
  getCacheStats(): { size: number; entries: string[] } {
    const detailEntries = Array.from(this.hotelDetailsCache.keys()).map((k) => `details:${k}`);
    const roomEntries = Array.from(this.hotelRoomDetailsCache.keys()).map((k) => `rooms:${k}`);

    return {
      size: this.hotelDetailsCache.size + this.hotelRoomDetailsCache.size,
      entries: [...detailEntries, ...roomEntries],
    };
  }
}

